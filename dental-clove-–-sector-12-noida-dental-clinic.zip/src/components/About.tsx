import React from 'react';
import { CheckCircle2, ShieldCheck, HeartHandshake, Eye, Sparkles } from 'lucide-react';
import { handleImageError } from '../utils/imageFallback.ts';

export const About: React.FC = () => {
  const checklist = [
    {
      title: 'Sterilised instruments',
      desc: 'Class-B hospital grade autoclave sterilisation and sealed disposable pouches opened in front of you.',
    },
    {
      title: 'Clear explanation before every treatment',
      desc: 'We explain dental findings clearly using digital X-rays before beginning any procedure.',
    },
    {
      title: 'Gentle care for anxious patients',
      desc: 'Unhurried appointments, warm local anaesthesia techniques, and a reassuring, calm chairside manner.',
    },
    {
      title: 'Transparent treatment plans',
      desc: 'Itemised pricing discussed in advance. No unexpected add-ons or unneeded procedures.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header & Vision Row matching Reference Image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-14">
          <div className="lg:col-span-5">
            <span className="text-3xl sm:text-4xl lg:text-5xl font-light text-slate-400 block tracking-tight">
              About
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight mt-1">
              Dental Clove
            </h2>
          </div>

          <div className="lg:col-span-7 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-500 block">
              Our Vision & Promise
            </span>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              At Dental Clove, our vision is to blend advanced dental technology with compassionate, unhurried care to create a welcoming space in Sector 12, Noida. Since 2016, our 2 resident specialists have aimed to inspire confident, healthy smiles through honest advice and gentle, personalized treatment.
            </p>
          </div>
        </div>

        {/* 4-Photo Asymmetrical Collage with Pill Tags matching Reference Image */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-14">
          {/* Photo 1: Clean Operatory Lounge with "Dental Care" pill */}
          <div className="md:col-span-6 relative rounded-3xl overflow-hidden shadow-md aspect-16/10 bg-slate-100 group">
            <img
              src="/images/operatory.jpg"
              alt="Modern sterilised dental operatory with ergonomic dental chair and Class-B autoclave equipment at Dental Clove in Sector 12 Noida"
              className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              loading="lazy"
              onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80')}
            />
            <div className="absolute bottom-4 left-4 bg-sky-100 text-sky-800 text-xs font-bold px-3.5 py-1 rounded-full shadow-xs">
              Dental Care
            </div>
          </div>

          {/* Photo 2: Patient Smile with "Tooth Alignment" pill & vertical "Dentures" tag */}
          <div className="md:col-span-6 relative rounded-3xl overflow-hidden shadow-md aspect-16/10 bg-slate-100 group">
            <img
              src="/images/patient-smile.jpg"
              alt="Happy patient smiling with straight, healthy teeth after orthodontic clear aligner therapy in Sector 12 Noida"
              className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              loading="lazy"
              onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=800&q=80')}
            />
            <div className="absolute bottom-4 right-4 bg-sky-100 text-sky-800 text-xs font-bold px-3.5 py-1 rounded-full shadow-xs">
              Tooth Alignment
            </div>
            <div className="absolute top-4 right-4 bg-orange-100/90 text-orange-800 text-[10px] font-bold px-2 py-1 rounded-md shadow-2xs rotate-90 origin-right">
              Gentle Care
            </div>
          </div>

          {/* Photo 3: Senior Patient Smiling with vertical "Dental Treatments" tag */}
          <div className="md:col-span-5 relative rounded-3xl overflow-hidden shadow-md aspect-4/3 bg-slate-100 group">
            <img
              src="/images/senior-patient.jpg"
              alt="Smiling patient receiving gentle, unhurried restorative dental consultation at Dental Clove in Sector 12 Noida"
              className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              loading="lazy"
              onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80')}
            />
            <div className="absolute bottom-4 left-4 bg-amber-100 text-amber-900 text-[11px] font-bold px-3 py-1 rounded-full shadow-xs flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>Dental Treatments</span>
            </div>
          </div>

          {/* Photo 4: Modern Dental Chair & Hygiene Equipment */}
          <div className="md:col-span-7 relative rounded-3xl overflow-hidden shadow-md aspect-4/3 bg-slate-100 group">
            <img
              src="/images/dental-chair.jpg"
              alt="Sterilised dental clinical chair with overhead LED lighting and ultrasonic scaling tools in Sector 12 Noida"
              className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
              loading="lazy"
              onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80')}
            />
            <div className="absolute bottom-4 left-4 bg-white/95 text-slate-800 text-xs font-bold px-3.5 py-1.5 rounded-full shadow-xs flex items-center gap-1.5 border border-slate-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Sterilised Operatory</span>
            </div>
          </div>
        </div>

        {/* 4-Point Checklist */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-100">
          {checklist.map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-50/80 rounded-2xl p-4 border border-slate-200/60 flex items-start gap-3"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-slate-900 leading-snug">
                  {item.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
