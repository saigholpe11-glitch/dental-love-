import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  Phone,
  User,
  MessageSquare,
  ArrowRight,
  MessageCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import {
  ALLOWED_TREATMENTS,
  validateBookingForm,
  createWhatsAppBookingLink,
  BookingFormData,
} from '../utils/booking.ts';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTreatment?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  defaultTreatment = '',
}) => {
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    phone: '',
    treatment: defaultTreatment || ALLOWED_TREATMENTS[0],
    preferredDate: '',
    preferredTime: '10:00 AM - 01:00 PM (Morning)',
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (defaultTreatment) {
      setFormData((prev) => ({ ...prev, treatment: defaultTreatment }));
    }
  }, [defaultTreatment]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const timeSlots = [
    '10:00 AM - 01:00 PM (Morning)',
    '02:00 PM - 05:00 PM (Afternoon)',
    '05:00 PM - 08:00 PM (Evening)',
  ];

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateBookingForm(formData);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }
    setErrors({});
    setIsSubmitted(true);
  };

  const whatsappDirectUrl = createWhatsAppBookingLink(formData);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-booking-title"
    >
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-sky-100 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-sky-600 to-sky-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-sky-200" />
            <div>
              <h2 id="modal-booking-title" className="text-lg font-bold">
                Book an Appointment
              </h2>
              <p className="text-xs text-sky-100">
                Dental Clove • Sector 12, Noida
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition text-white"
            aria-label="Close appointment modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {isSubmitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Booking Request Sent!
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-sm mx-auto">
                Thank you, <span className="font-bold text-slate-900">{formData.fullName}</span>. We have received your booking request for{' '}
                <span className="font-bold text-sky-700">{formData.treatment}</span>. We will call you at{' '}
                <span className="font-bold text-slate-900">{formData.phone}</span> to confirm.
              </p>

              <div className="pt-2 flex flex-col gap-2.5">
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-3 rounded-full flex items-center justify-center gap-2 shadow-xs transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Confirmation on WhatsApp</span>
                </a>
                <button
                  type="button"
                  onClick={onClose}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs py-2.5 rounded-full transition"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Full Name */}
              <div className="space-y-1">
                <label
                  htmlFor="modal-name"
                  className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                >
                  <User className="w-3.5 h-3.5 text-sky-600" />
                  <span>Full Name *</span>
                </label>
                <input
                  type="text"
                  id="modal-name"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="e.g. Rahul Sharma"
                  className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                    errors.fullName ? 'border-rose-500' : 'border-slate-200'
                  }`}
                />
                {errors.fullName && (
                  <p className="text-xs text-rose-500">{errors.fullName}</p>
                )}
              </div>

              {/* Phone */}
              <div className="space-y-1">
                <label
                  htmlFor="modal-phone"
                  className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-sky-600" />
                  <span>Mobile Number (+91) *</span>
                </label>
                <input
                  type="tel"
                  id="modal-phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="e.g. 98765 43210"
                  className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                    errors.phone ? 'border-rose-500' : 'border-slate-200'
                  }`}
                />
                {errors.phone && (
                  <p className="text-xs text-rose-500">{errors.phone}</p>
                )}
              </div>

              {/* Treatment */}
              <div className="space-y-1">
                <label
                  htmlFor="modal-treatment"
                  className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                  <span>Treatment *</span>
                </label>
                <select
                  id="modal-treatment"
                  name="treatment"
                  value={formData.treatment}
                  onChange={handleChange}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition"
                >
                  {ALLOWED_TREATMENTS.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
                {errors.treatment && (
                  <p className="text-xs text-rose-500">{errors.treatment}</p>
                )}
              </div>

              {/* Date & Time Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label
                    htmlFor="modal-date"
                    className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                  >
                    <Calendar className="w-3.5 h-3.5 text-sky-600" />
                    <span>Preferred Date *</span>
                  </label>
                  <input
                    type="date"
                    id="modal-date"
                    name="preferredDate"
                    min={minDate}
                    value={formData.preferredDate}
                    onChange={handleChange}
                    className={`w-full bg-slate-50 border rounded-xl px-3 py-2 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                      errors.preferredDate ? 'border-rose-500' : 'border-slate-200'
                    }`}
                  />
                  {errors.preferredDate && (
                    <p className="text-xs text-rose-500">{errors.preferredDate}</p>
                  )}
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="modal-time"
                    className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                  >
                    <Clock className="w-3.5 h-3.5 text-sky-600" />
                    <span>Slot *</span>
                  </label>
                  <select
                    id="modal-time"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleChange}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot.split(' ')[0]} {slot.includes('Morning') ? 'Morning' : slot.includes('Afternoon') ? 'Afternoon' : 'Evening'}
                      </option>
                    ))}
                  </select>
                  {errors.preferredTime && (
                    <p className="text-xs text-rose-500">{errors.preferredTime}</p>
                  )}
                </div>
              </div>

              {/* Optional Notes */}
              <div className="space-y-1">
                <label
                  htmlFor="modal-notes"
                  className="text-xs font-semibold text-slate-700 flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-sky-600" />
                  <span>Notes (Optional)</span>
                </label>
                <input
                  type="text"
                  id="modal-notes"
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  placeholder="e.g. Sensitive tooth, check-up for child"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition"
                />
              </div>

              {/* Buttons */}
              <div className="pt-3 space-y-2">
                <button
                  type="submit"
                  className="w-full bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm py-3 rounded-full shadow-md shadow-orange-500/20 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <span>Confirm Booking Request</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs py-2.5 rounded-full flex items-center justify-center gap-2 transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Book via WhatsApp Instead</span>
                </a>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
