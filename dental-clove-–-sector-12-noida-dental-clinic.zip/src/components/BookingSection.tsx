import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Phone,
  User,
  MessageSquare,
  ArrowRight,
  MessageCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import {
  ALLOWED_TREATMENTS,
  validateBookingForm,
  createWhatsAppBookingLink,
  BookingFormData,
} from '../utils/booking.ts';

interface BookingSectionProps {
  initialTreatment?: string;
}

export const BookingSection: React.FC<BookingSectionProps> = ({ initialTreatment = '' }) => {
  const [formData, setFormData] = useState<BookingFormData>({
    fullName: '',
    phone: '',
    treatment: initialTreatment || ALLOWED_TREATMENTS[0],
    preferredDate: '',
    preferredTime: '10:00 AM - 01:00 PM (Morning)',
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Time slot options
  const timeSlots = [
    '10:00 AM - 01:00 PM (Morning)',
    '02:00 PM - 05:00 PM (Afternoon)',
    '05:00 PM - 08:00 PM (Evening)',
  ];

  // Get tomorrow's date string for input min attribute
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateBookingForm(formData);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    // Success flow
    setErrors({});
    setIsSubmitted(true);
  };

  const whatsappDirectUrl = createWhatsAppBookingLink(formData);

  return (
    <section id="book" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Navy "Ready to Book" Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-950 border border-sky-800 text-sky-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ready to Visit Dental Clove?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white">
            Book Your Dental <span className="text-sky-400">Appointment</span>
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            Serving Sector 12, Noida with gentle, prompt appointments. Submit your details below or chat instantly on WhatsApp.
          </p>
        </div>

        {/* Main Booking Container */}
        <div className="max-w-3xl mx-auto bg-slate-800/80 border border-slate-700 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-none">
          {isSubmitted ? (
            <div className="text-center py-10 space-y-6 animate-in fade-in zoom-in-95 duration-300">
              <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white">
                  Appointment Request Received!
                </h3>
                <p className="text-slate-300 max-w-md mx-auto text-sm leading-relaxed">
                  Thank you, <span className="text-white font-semibold">{formData.fullName}</span>. Our clinic coordinator in Sector 12, Noida will call or WhatsApp you at <span className="text-white font-semibold">{formData.phone}</span> shortly to confirm your slot for <span className="text-sky-400 font-semibold">{formData.treatment}</span>.
                </p>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-6 py-3 rounded-full flex items-center justify-center gap-2 shadow-md transition"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Details on WhatsApp</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    setIsSubmitted(false);
                    setFormData({
                      fullName: '',
                      phone: '',
                      treatment: ALLOWED_TREATMENTS[0],
                      preferredDate: '',
                      preferredTime: timeSlots[0],
                      notes: '',
                    });
                  }}
                  className="w-full sm:w-auto bg-slate-700 hover:bg-slate-600 text-white font-semibold text-sm px-6 py-3 rounded-full transition"
                >
                  Book Another Visit
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Form Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* Full Name */}
                <div className="space-y-1.5">
                  <label htmlFor="fullName" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-sky-400" />
                    <span>Your Full Name *</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="e.g. Rahul Sharma"
                    className={`w-full bg-slate-900 border rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                      errors.fullName ? 'border-rose-500' : 'border-slate-700'
                    }`}
                  />
                  {errors.fullName && (
                    <p className="text-xs text-rose-400">{errors.fullName}</p>
                  )}
                </div>

                {/* Phone Number */}
                <div className="space-y-1.5">
                  <label htmlFor="phone" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-sky-400" />
                    <span>Mobile Number (+91) *</span>
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="e.g. 98765 43210"
                    className={`w-full bg-slate-900 border rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                      errors.phone ? 'border-rose-500' : 'border-slate-700'
                    }`}
                  />
                  {errors.phone && (
                    <p className="text-xs text-rose-400">{errors.phone}</p>
                  )}
                </div>

                {/* Preferred Treatment Dropdown */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label htmlFor="treatment" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                    <span>Preferred Treatment *</span>
                  </label>
                  <select
                    id="treatment"
                    name="treatment"
                    value={formData.treatment}
                    onChange={handleChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition"
                  >
                    {ALLOWED_TREATMENTS.map((t) => (
                      <option key={t} value={t} className="bg-slate-900 text-white">
                        {t}
                      </option>
                    ))}
                  </select>
                  {errors.treatment && (
                    <p className="text-xs text-rose-400">{errors.treatment}</p>
                  )}
                </div>

                {/* Preferred Date */}
                <div className="space-y-1.5">
                  <label htmlFor="preferredDate" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-sky-400" />
                    <span>Preferred Date *</span>
                  </label>
                  <input
                    type="date"
                    id="preferredDate"
                    name="preferredDate"
                    min={minDate}
                    value={formData.preferredDate}
                    onChange={handleChange}
                    className={`w-full bg-slate-900 border rounded-2xl px-4 py-3 text-sm text-white focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition ${
                      errors.preferredDate ? 'border-rose-500' : 'border-slate-700'
                    }`}
                  />
                  {errors.preferredDate && (
                    <p className="text-xs text-rose-400">{errors.preferredDate}</p>
                  )}
                </div>

                {/* Preferred Time Slot */}
                <div className="space-y-1.5">
                  <label htmlFor="preferredTime" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-sky-400" />
                    <span>Preferred Time Slot *</span>
                  </label>
                  <select
                    id="preferredTime"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot} className="bg-slate-900 text-white">
                        {slot}
                      </option>
                    ))}
                  </select>
                  {errors.preferredTime && (
                    <p className="text-xs text-rose-400">{errors.preferredTime}</p>
                  )}
                </div>

                {/* Optional Message */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label htmlFor="notes" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                    <span>Any specific concern or symptoms? (Optional)</span>
                  </label>
                  <textarea
                    id="notes"
                    name="notes"
                    rows={2}
                    value={formData.notes}
                    onChange={handleChange}
                    placeholder="e.g. Sensitivity to cold drinks, interested in aligners EMI"
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-sky-500 transition resize-none"
                  ></textarea>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-4">
                {/* Vivid orange CTA button */}
                <button
                  type="submit"
                  className="w-full sm:flex-1 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-base py-3.5 px-6 rounded-full shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <span>Book Appointment</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                {/* Secondary WhatsApp button */}
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm py-3.5 px-6 rounded-full flex items-center justify-center gap-2 transition"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>WhatsApp Instead</span>
                </a>
              </div>

              <div className="text-center text-xs text-slate-400">
                🔒 Your details are private. We never send promotional spam.
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
