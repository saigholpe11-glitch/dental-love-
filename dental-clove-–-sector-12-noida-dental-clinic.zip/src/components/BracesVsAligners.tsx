import React, { useState } from 'react';
import { ArrowRight, Check, Sparkles, HelpCircle, Eye, Box } from 'lucide-react';
import { BRACES_VS_ALIGNERS_DATA } from '../utils/booking.ts';
import { ThreeToothViewer } from './ThreeToothViewer.tsx';

interface BracesVsAlignersProps {
  onOpenBooking: () => void;
}

export const BracesVsAligners: React.FC<BracesVsAlignersProps> = ({ onOpenBooking }) => {
  const [activeTab, setActiveTab] = useState<'comparison' | '3d-studio'>('comparison');

  return (
    <section id="braces-vs-aligners" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <span>Orthodontic Guide</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Traditional Braces vs <span className="text-sky-600">Clear Aligners</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Wondering which teeth-straightening method fits your lifestyle, budget, and dental needs? Here is our friendly, honest breakdown.
          </p>

          {/* View Mode Toggle (Comparison Matrix vs 3D Explorer) */}
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-2xl border border-slate-200 mt-2">
            <button
              type="button"
              onClick={() => setActiveTab('comparison')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
                activeTab === 'comparison'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <HelpCircle className="w-4 h-4 text-sky-600" />
              <span>Side-by-Side Comparison</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('3d-studio')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
                activeTab === '3d-studio'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Box className="w-4 h-4" />
              <span>Interactive 3D Aligner Model</span>
              <span className="text-[10px] bg-sky-500/20 px-1.5 py-0.5 rounded font-black hidden xs:inline">
                3D
              </span>
            </button>
          </div>
        </div>

        {/* Tab 1: Side by side comparison cards / table */}
        {activeTab === 'comparison' && (
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Quick Summary Cards (Braces vs Aligners) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
              {/* Braces Card */}
              <div className="bg-slate-50/70 border border-slate-200/90 rounded-3xl p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500 bg-white px-3 py-1 rounded-full border border-slate-200">
                      Fixed Orthodontics
                    </span>
                    <span className="text-xs text-slate-500 font-medium">Metal or Ceramic</span>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Traditional Braces</h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    Fixed brackets and archwires that guide tooth movement 24 hours a day. Highly effective for deep bite corrections and severe crowding.
                  </p>

                  <div className="space-y-3 text-sm text-slate-700">
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>Zero compliance risk — stays on 24/7 without being misplaced</span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>Handles complex skeletal bite discrepancies reliably</span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>Pocket-friendly pricing with flexible monthly payment plans</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Aligners Card */}
              <div className="bg-gradient-to-b from-sky-50/60 to-white border-2 border-sky-300/80 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-sky-600 text-white text-[11px] font-bold px-3 py-1 rounded-bl-xl shadow-xs">
                  Most Popular
                </div>
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-sky-800 bg-sky-100 px-3 py-1 rounded-full">
                      Removable Trays
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Clear Aligners</h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    Transparent, custom 3D-printed aligner trays that gently shift teeth into place without visible metal or food restrictions.
                  </p>

                  <div className="space-y-3 text-sm text-slate-700">
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                      <span>Nearly invisible — smile with complete confidence during meetings</span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                      <span>Remove to eat whatever you want & brush normally</span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                      <span>Fewer clinic appointments required (change trays at home)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Comparison Table */}
            <div className="max-w-5xl mx-auto bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-100/80 text-slate-900 text-xs uppercase font-bold tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="py-4 px-6 w-1/4">Comparison Factor</th>
                      <th className="py-4 px-6 w-3/8 text-slate-700">Traditional Braces</th>
                      <th className="py-4 px-6 w-3/8 text-sky-900 bg-sky-50/70">Clear Aligners</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {BRACES_VS_ALIGNERS_DATA.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 transition">
                        <td className="py-4 px-6 font-semibold text-slate-900">
                          <div>{row.feature}</div>
                          {row.tag && (
                            <span className="inline-block mt-1 text-[10px] font-bold text-sky-700 bg-sky-100/70 px-2 py-0.5 rounded-full">
                              {row.tag}
                            </span>
                          )}
                        </td>
                        <td className="py-4 px-6 text-slate-600 leading-relaxed">{row.braces}</td>
                        <td className="py-4 px-6 text-slate-800 leading-relaxed font-medium bg-sky-50/30">
                          {row.aligners}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Three.js Interactive 3D Aligner & Tooth Studio */}
        {activeTab === '3d-studio' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl p-4 sm:p-6 border border-sky-200 shadow-sm">
              <div className="mb-4 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-2">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">
                    Interactive 3D Aligner & Molar Explorer
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500">
                    Examine how a transparent orthodontic aligner fits over natural tooth enamel. Drag to rotate in 3D.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-sky-700 font-semibold bg-sky-50 px-3 py-1.5 rounded-xl border border-sky-100">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Real-time Three.js PBR</span>
                </div>
              </div>

              {/* Three.js Interactive Canvas Component */}
              <ThreeToothViewer />
            </div>
          </div>
        )}

        {/* End of Section Consultation CTA */}
        <div className="mt-12 text-center bg-slate-50 rounded-3xl p-8 border border-slate-200/80 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-center sm:text-left">
            <h4 className="text-lg font-bold text-slate-900">
              Not sure which is right for your smile?
            </h4>
            <p className="text-sm text-slate-600 mt-1">
              Visit our Sector 12 clinic for an assessment. We will scan your teeth and explain all pros, cons, and costs.
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenBooking}
            className="shrink-0 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm px-7 py-3 rounded-full shadow-md shadow-orange-500/20 hover:shadow-orange-500/30 flex items-center gap-2 transition cursor-pointer"
          >
            <span>Book a Consultation</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
