import React from 'react';
import { Award, Clock, GraduationCap, CheckCircle } from 'lucide-react';
import { handleImageError } from '../utils/imageFallback.ts';

interface DoctorsProps {
  onOpenBooking: () => void;
}

export const Doctors: React.FC<DoctorsProps> = ({ onOpenBooking }) => {
  const doctors = [
    {
      id: 1,
      name: '[DOCTOR 1 NAME]',
      degree: '[DOCTOR 1 DEGREE]',
      specialisation: 'Orthodontics & Dentofacial Orthopaedics',
      experience: '[YEARS OF EXPERIENCE] (12+ Years)',
      summary:
        'Specialises in braces and clear aligner therapies for teens and adults, focusing on gentle bite correction and aesthetic smile enhancements.',
      image: '/images/doctor1.jpg',
      remoteFallback: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=700&q=80',
      keyPoints: [
        'Certified Clear Aligner Provider',
        'Preventive & Interceptive Orthodontics',
        'Practising in Noida since 2016',
      ],
    },
    {
      id: 2,
      name: '[DOCTOR 2 NAME]',
      degree: '[DOCTOR 2 DEGREE]',
      specialisation: 'Conservative Dentistry & Endodontics',
      experience: '[YEARS OF EXPERIENCE] (10+ Years)',
      summary:
        'Expert in single-sitting rotary root canals, aesthetic tooth-coloured restorations, and gentle paediatric care for anxious young patients.',
      image: '/images/doctor2.jpg',
      remoteFallback: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=700&q=80',
      keyPoints: [
        'Microscopic & Rotary Endodontics Specialist',
        'Fear-Free Paediatric Dental Techniques',
        'Dedicated to Natural Tooth Preservation',
      ],
    },
  ];

  return (
    <section id="doctors" className="py-20 bg-sky-50/40 border-y border-sky-100/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <span>Resident Specialists</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Meet the <span className="text-sky-600">Doctors</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Experienced, caring dental surgeons providing continuity of care for Noida families. You are always treated by the same senior doctors.
          </p>
        </div>

        {/* Exactly 2 Doctor Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {doctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-3xl p-6 sm:p-8 border border-sky-100/90 shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                {/* Doctor Photo & Badges */}
                <div className="relative rounded-2xl overflow-hidden aspect-4/3 mb-6 bg-slate-100 border border-slate-100">
                  <img
                    src={doc.image}
                    alt={`Portrait of ${doc.name}, ${doc.degree}, specialist in ${doc.specialisation} providing orthodontic and endodontic care at Dental Clove in Sector 12 Noida`}
                    className="w-full h-full object-cover object-top"
                    loading="lazy"
                    onError={(e) => handleImageError(e, doc.remoteFallback)}
                  />
                  <div className="absolute top-3 left-3 bg-white/95 px-3 py-1 rounded-full text-xs font-bold text-slate-800 shadow-xs flex items-center gap-1.5 border border-slate-100">
                    <Clock className="w-3.5 h-3.5 text-sky-600" />
                    <span>{doc.experience}</span>
                  </div>
                </div>

                {/* Name & Degree Placeholder */}
                <div className="space-y-1.5 mb-4">
                  <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
                    {doc.name}
                  </h3>
                  <div className="inline-flex items-center gap-1.5 text-sky-700 text-sm font-semibold">
                    <GraduationCap className="w-4 h-4" />
                    <span>{doc.degree}</span>
                  </div>
                </div>

                {/* Specialisation Pill */}
                <div className="mb-4">
                  <span className="inline-block px-3 py-1 bg-sky-50 text-sky-800 text-xs font-bold rounded-lg border border-sky-100">
                    {doc.specialisation}
                  </span>
                </div>

                <p className="text-sm text-slate-600 leading-relaxed mb-6">
                  {doc.summary}
                </p>

                {/* Key focus areas */}
                <div className="space-y-2 mb-6 text-xs text-slate-700">
                  {doc.keyPoints.map((point, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{point}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Consultation CTA */}
              <div className="pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="w-full bg-slate-900 hover:bg-sky-600 text-white font-semibold text-sm py-3 rounded-2xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Award className="w-4 h-4" />
                  <span>Consult with {doc.name.split(',')[0]}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
