import React from 'react';
import { MessageSquareText, Search, FileText, CheckCircle, ArrowRight } from 'lucide-react';

interface FirstVisitStepsProps {
  onOpenBooking: () => void;
}

export const FirstVisitSteps: React.FC<FirstVisitStepsProps> = ({ onOpenBooking }) => {
  const steps = [
    {
      num: '01',
      title: 'Consultation',
      desc: 'We sit down with you to listen carefully to your concerns, dental history, and any sensitivities. No rush.',
      icon: MessageSquareText,
    },
    {
      num: '02',
      title: 'Check-up & X-ray (If Needed)',
      desc: 'Thorough gentle oral examination. If an X-ray is required, we use ultra-low radiation digital sensors right in the chair.',
      icon: Search,
    },
    {
      num: '03',
      title: 'Clear Treatment Plan & Cost',
      desc: 'You see the images with us. We explain all clinical options, timelines, and exact costs upfront before any work starts.',
      icon: FileText,
    },
    {
      num: '04',
      title: 'Treatment (At Your Pace)',
      desc: 'Proceed only when you feel completely informed and ready. We provide gentle, painless treatment with pause cues anytime.',
      icon: CheckCircle,
    },
  ];

  return (
    <section className="py-20 bg-slate-50 border-t border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <span>Simple & Transparent</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            What to Expect on Your <span className="text-sky-600">First Visit</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Visiting the dentist shouldn&apos;t be intimidating. Here is how your first appointment at Dental Clove unfolds step-by-step.
          </p>
        </div>

        {/* 4 Connected Step Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="bg-white rounded-3xl p-6 sm:p-7 border border-sky-100/80 shadow-xs hover:shadow-md transition flex flex-col justify-between relative group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-2xl font-black text-sky-600/30 group-hover:text-sky-600 transition">
                      {step.num}
                    </span>
                    <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition">
                      <Icon className="w-6 h-6 stroke-[1.8]" />
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 mb-2">{step.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{step.desc}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center text-xs font-bold text-sky-600">
                  <span>Step {idx + 1} of 4</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reassuring Banner */}
        <div className="mt-12 text-center">
          <p className="text-sm font-medium text-slate-500 mb-4">
            Have dental anxiety? Let us know when booking, and we will set aside extra quiet time for you.
          </p>
          <button
            type="button"
            onClick={onOpenBooking}
            className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm px-7 py-3 rounded-full shadow-md shadow-orange-500/20 transition cursor-pointer"
          >
            <span>Book Your First Visit</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
