import React from 'react';
import { MessageCircle } from 'lucide-react';
import { createWhatsAppBookingLink } from '../utils/booking.ts';

export const FloatingWhatsApp: React.FC = () => {
  const whatsappUrl = createWhatsAppBookingLink({
    fullName: '',
    treatment: 'Consultation',
  });

  return (
    <aside aria-label="Quick WhatsApp assistance" className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat directly on WhatsApp with Dental Clove clinic"
        className="flex items-center gap-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm px-4 py-3 rounded-full shadow-xl shadow-emerald-500/30 hover:scale-105 active:scale-95 transition"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="hidden sm:inline">Chat on WhatsApp</span>
      </a>
    </aside>
  );
};
