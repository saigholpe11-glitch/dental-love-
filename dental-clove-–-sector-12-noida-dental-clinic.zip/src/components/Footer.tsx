import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, ArrowUpRight, BookOpen } from 'lucide-react';
import { ALLOWED_TREATMENTS } from '../utils/booking.ts';
import { BLOG_ARTICLES, CLINIC_NAP } from '../data/blogData.ts';

export const Footer: React.FC = () => {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <footer className="bg-slate-950 text-slate-400 text-sm border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Brand & Tagline */}
          <div className="lg:col-span-4 space-y-4">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-sky-500 flex items-center justify-center text-white font-bold shadow-xs">
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current" aria-hidden="true">
                  <path d="M12 2C8.5 2 6 4.8 6 8.5c0 3 1.5 6.5 2.5 10 .8 2.8 1.8 3.5 3.5 3.5 1.7 0 2.7-.7 3.5-3.5 1-3.5 2.5-7 2.5-10C18 4.8 15.5 2 12 2zm-1 16.5c-.8 0-1.5-1.5-2.2-4.2C8 11.2 7.5 8.7 7.5 8.5 7.5 5.8 9.4 3.5 12 3.5s4.5 2.3 4.5 5c0 .2-.5 2.7-1.3 5.8-.7 2.7-1.4 4.2-2.2 4.2-.7 0-1.2-.8-1.5-2-.3 1.2-.8 2-1.5 2z" />
                </svg>
              </div>
              <span className="text-xl font-bold tracking-tight text-white">{CLINIC_NAP.name}</span>
            </Link>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              Gentle, honest dental care in Sector 12, Noida since {CLINIC_NAP.foundingDate}. Unhurried consultations,
              modern hospital-grade sterilisation, and personalised treatments for your whole family.
            </p>

            <div className="pt-1 text-xs text-slate-400">
              <p>
                <strong className="text-slate-300">Areas Served:</strong> Sector 12, Sector 18, Sector 62, Noida Extension,
                Greater Noida, Indirapuram, and Delhi NCR.
              </p>
            </div>

            <div className="pt-2 flex items-center gap-2.5">
              {['Facebook [LINKS]', 'Instagram [LINKS]', 'Google [LINKS]'].map((soc) => (
                <a
                  key={soc}
                  href={isHome ? '#contact' : '/#contact'}
                  className="px-3 py-1 bg-slate-900 hover:bg-sky-600 hover:text-white rounded-lg text-xs font-medium border border-slate-800 transition"
                >
                  {soc}
                </a>
              ))}
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-2 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Quick Links</h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <Link to="/" className="hover:text-white transition">
                  Home
                </Link>
              </li>
              <li>
                <a href={isHome ? '#about' : '/#about'} className="hover:text-white transition">
                  About Clinic
                </a>
              </li>
              <li>
                <a href={isHome ? '#treatments' : '/#treatments'} className="hover:text-white transition">
                  Treatments
                </a>
              </li>
              <li>
                <a href={isHome ? '#doctors' : '/#doctors'} className="hover:text-white transition">
                  Our Doctors
                </a>
              </li>
              <li>
                <a href={isHome ? '#braces-vs-aligners' : '/#braces-vs-aligners'} className="hover:text-white transition">
                  Braces vs Aligners
                </a>
              </li>
              <li>
                <Link to="/blog" className="text-sky-400 hover:text-sky-300 font-semibold transition flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Dental Blog</span>
                </Link>
              </li>
              <li>
                <a href={isHome ? '#faq' : '/#faq'} className="hover:text-white transition">
                  FAQ
                </a>
              </li>
              <li>
                <a href={isHome ? '#book' : '/#book'} className="text-orange-400 hover:text-orange-300 font-semibold transition">
                  Book Appointment
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Dental Blog Articles */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Dental Guides (Noida)</h4>
            <ul className="space-y-3 text-xs">
              {BLOG_ARTICLES.map((article) => (
                <li key={article.slug}>
                  <Link
                    to={`/blog/${article.slug}`}
                    className="hover:text-sky-400 transition block leading-snug text-slate-300"
                  >
                    <span className="font-medium">{article.title}</span>
                    <span className="text-[10px] text-slate-500 block mt-0.5">Reviewed {article.lastReviewedDate}</span>
                  </Link>
                </li>
              ))}
            </ul>

            <div className="pt-2 border-t border-slate-900">
              <span className="text-[11px] text-slate-400 block font-semibold mb-1.5">Treatments</span>
              <div className="flex flex-wrap gap-1.5">
                {ALLOWED_TREATMENTS.map((t) => (
                  <a
                    key={t}
                    href={isHome ? '#treatments' : '/#treatments'}
                    className="text-[11px] px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
                  >
                    {t}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Col 4: Contact Details & NAP Block */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Contact &amp; Location</h4>
            <div className="space-y-3 text-xs sm:text-sm text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>
                  {CLINIC_NAP.name}, {CLINIC_NAP.streetAddress}, {CLINIC_NAP.locality}, {CLINIC_NAP.region} {CLINIC_NAP.postalCode}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-sky-400 shrink-0" />
                <a href={`tel:${CLINIC_NAP.phone}`} className="hover:text-white">
                  {CLINIC_NAP.phone}
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                <a href={`mailto:${CLINIC_NAP.email}`} className="hover:text-white">
                  {CLINIC_NAP.email}
                </a>
              </div>
              <div className="flex items-start gap-2.5 pt-1">
                <Clock className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <p>Mon - Sat: 10:00 AM - 08:00 PM</p>
                  <p className="text-sky-400">Sun: 10:00 AM - 02:00 PM (By Appt)</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Disclaimer */}
        <div className="mt-14 pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} {CLINIC_NAP.name}, Sector 12, Noida. All rights reserved.</p>
          <p>Gentle Dental Care in Sector 12, Noida since {CLINIC_NAP.foundingDate}. Transparent pricing from ₹[CLINIC PRICE].</p>
        </div>
      </div>
    </footer>
  );
};
