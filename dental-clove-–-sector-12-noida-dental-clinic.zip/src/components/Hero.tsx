import React from 'react';
import { motion } from 'motion/react';
import {
  ArrowUpRight,
  MessageCircle,
  Calendar,
  Users,
  Stethoscope,
  ShieldCheck,
  MapPin,
  Clock,
  Sparkles,
} from 'lucide-react';
import { createWhatsAppBookingLink, ALLOWED_TREATMENTS } from '../utils/booking.ts';
import { handleImageError } from '../utils/imageFallback.ts';

interface HeroProps {
  onOpenBooking: (treatmentName?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  const whatsappUrl = createWhatsAppBookingLink({
    fullName: '',
    treatment: 'Consultation',
  });

  return (
    <section
      id="home"
      className="relative overflow-hidden pt-6 pb-16 md:pt-10 md:pb-24 bg-gradient-to-b from-sky-100/50 via-white to-sky-50/30"
    >
      {/* Reference Image Large Headline: "EVERY SMILE MATTERS" across the top with subtle bounce */}
      <motion.div
        initial={{ opacity: 0, y: -15 }}
        animate={{
          opacity: 1,
          y: [0, -6, 0],
        }}
        transition={{
          opacity: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
          y: { duration: 3.5, repeat: Infinity, ease: 'easeInOut' },
        }}
        className="w-full text-center select-none pointer-events-none mb-4 md:mb-6 px-4"
      >
        <span className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-sky-500/20 sm:text-sky-500/25 uppercase font-sans">
          EVERY SMILE MATTERS
        </span>
      </motion.div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Hero Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">
          
          {/* Left Column: Headline, Clinic info card, and animated CTAs */}
          <div className="lg:col-span-5 space-y-6 text-center lg:text-left">
            {/* Top Local Clinic Badge */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.05 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 text-sky-800 text-xs sm:text-sm font-semibold border border-sky-200 shadow-2xs"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-sky-600" />
                Sector 12, Noida • Welcoming New Patients
              </span>
            </motion.div>

            {/* Hero Main Headline with Text Bouncing Effect on "Smiles" & spring slide-up */}
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]"
            >
              Healthy{' '}
              <span className="inline-inline-flex whitespace-nowrap">
                {['S', 'm', 'i', 'l', 'e', 's'].map((char, index) => (
                  <motion.span
                    key={index}
                    className="inline-block text-sky-600 transition-colors hover:text-sky-500 cursor-pointer select-none"
                    initial={{ y: 0 }}
                    animate={{
                      y: [0, -10, 0, -3, 0],
                    }}
                    transition={{
                      duration: 1.6,
                      repeat: Infinity,
                      repeatDelay: 1.8,
                      delay: 0.5 + index * 0.1,
                      ease: [0.34, 1.56, 0.64, 1],
                    }}
                    whileHover={{
                      y: -14,
                      scale: 1.2,
                      rotate: index % 2 === 0 ? -6 : 6,
                      transition: { type: 'spring', stiffness: 500, damping: 10 },
                    }}
                  >
                    {char}
                  </motion.span>
                ))}
              </span>
              , <br className="hidden sm:inline" />
              Close to Home
            </motion.h1>

            {/* Reference-inspired Rounded Card */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white/90 backdrop-blur-none border border-sky-100 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4"
            >
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
                Our 2 experienced resident dentists use modern sterilisation and gentle techniques to offer complete, honest dental care in a comfortable environment in Sector 12, Noida.
              </p>

              {/* Clinic Timings */}
              <div className="pt-1 flex items-center justify-center lg:justify-start gap-2 text-xs font-semibold text-slate-700">
                <Clock className="w-4 h-4 text-sky-600" />
                <span>We&apos;re Open: <strong className="text-slate-900">10:00 AM – 08:00 PM</strong> (Mon – Sat)</span>
              </div>
            </motion.div>

            {/* CTA Buttons with Motion Entrance and Interactive Hover Physics */}
            <motion.div
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-1"
            >
              {/* Vivid Orange Pill CTA matching Reference with animated bouncing arrow */}
              <motion.button
                type="button"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onOpenBooking()}
                className="w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white font-bold text-base px-8 py-3.5 rounded-full shadow-lg shadow-orange-500/25 hover:shadow-orange-500/35 flex items-center justify-center gap-2 transition cursor-pointer group"
              >
                <span>BOOK APPOINTMENT</span>
                <motion.span
                  animate={{
                    x: [0, 2.5, 0],
                    y: [0, -2.5, 0],
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 1.4,
                    ease: 'easeInOut',
                  }}
                  className="inline-flex"
                >
                  <ArrowUpRight className="w-5 h-5 group-hover:rotate-12 transition-transform duration-200" />
                </motion.span>
              </motion.button>

              {/* Secondary WhatsApp Pill */}
              <motion.a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base px-7 py-3.5 rounded-full shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition"
              >
                <MessageCircle className="w-5 h-5" />
                <span>WhatsApp Us</span>
              </motion.a>
            </motion.div>

            {/* Quick-Pick Treatment Chips */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.45 }}
              className="pt-1"
            >
              <div className="text-xs font-semibold text-slate-500 mb-2 flex items-center justify-center lg:justify-start gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                <span>Quick-select treatment:</span>
              </div>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-1.5">
                {ALLOWED_TREATMENTS.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => onOpenBooking(t)}
                    className="text-xs bg-white hover:bg-sky-50 text-slate-700 hover:text-sky-700 font-medium px-3 py-1 rounded-full border border-slate-200/90 shadow-2xs transition cursor-pointer"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Trust Checks */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.55 }}
              className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-slate-500"
            >
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-sky-600" />
                <span>Hospital-Grade Sterilisation</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-sky-600" />
                <span>No Hidden Charges</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-sky-600" />
                <span>Easy EMI Available</span>
              </div>
            </motion.div>
          </div>

          {/* Center Column: Glossy Hero Visual with Splash Backdrop */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative flex justify-center items-center"
          >
            <div className="relative w-full max-w-md sm:max-w-lg">
              {/* Soft splash glow & decorative backdrop */}
              <div className="absolute -inset-6 bg-gradient-to-tr from-sky-300/40 via-blue-200/30 to-cyan-200/40 rounded-full blur-3xl -z-10 transform scale-105"></div>

              {/* Main Photo with Rounded Aesthetic matching Reference */}
              <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white aspect-4/3 sm:aspect-square bg-slate-100 group">
                <img
                  src="/images/hero.jpg"
                  alt="Friendly dental examination and confident smiling patient at Dental Clove, Sector 12 Noida"
                  className="w-full h-full object-cover group-hover:scale-102 transition duration-700"
                  loading="eager"
                  fetchPriority="high"
                  onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=1000&q=80')}
                />

                {/* Subtle gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent"></div>
              </div>

              {/* Floating Badge Over Image: "Serving Noida since 2016" */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.45 }}
                className="absolute -bottom-4 sm:-bottom-5 -left-2 sm:-left-5 bg-white border border-sky-100 rounded-2xl p-3 sm:p-4 shadow-xl flex items-center gap-3 z-20"
              >
                <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-xs">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] text-slate-500 font-medium">Trusted Healthcare</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900">
                    Serving Noida since 2016
                  </div>
                </div>
              </motion.div>

              {/* Floating Badge Top Right: Sector 12 Clinic */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="absolute -top-3 -right-2 sm:-right-4 bg-white/95 border border-slate-200/80 rounded-full px-3.5 py-1.5 shadow-md flex items-center gap-2 text-xs font-bold text-slate-700 z-20"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                <span>Sector 12, Noida Clinic</span>
              </motion.div>
            </div>
          </motion.div>

          {/* Right Column: Hero Stats matching Reference layout */}
          <motion.div
            initial={{ opacity: 0, x: 25 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-2 flex flex-row lg:flex-col justify-center items-center lg:items-start gap-4 sm:gap-6 pt-4 lg:pt-0"
          >
            {/* Stat 1: Since 2016 */}
            <div className="text-center lg:text-left bg-white/80 lg:bg-transparent p-3 lg:p-0 rounded-2xl border lg:border-none border-sky-100 flex-1 lg:flex-none">
              <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-sky-600 tracking-tight">
                2016
              </div>
              <div className="text-xs font-bold text-slate-900 mt-0.5">Serving Patients</div>
              <div className="text-[11px] text-slate-500">Sector 12, Noida</div>
            </div>

            {/* Stat 2: 2 Doctors */}
            <div className="text-center lg:text-left bg-white/80 lg:bg-transparent p-3 lg:p-0 rounded-2xl border lg:border-none border-sky-100 flex-1 lg:flex-none">
              <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-sky-600 tracking-tight">
                2+
              </div>
              <div className="text-xs font-bold text-slate-900 mt-0.5">Experienced Doctors</div>
              <div className="text-[11px] text-slate-500">Orthodontist & Endodontist</div>
            </div>

            {/* Stat 3: 7 Treatments */}
            <div className="text-center lg:text-left bg-white/80 lg:bg-transparent p-3 lg:p-0 rounded-2xl border lg:border-none border-sky-100 flex-1 lg:flex-none">
              <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-sky-600 tracking-tight">
                07
              </div>
              <div className="text-xs font-bold text-slate-900 mt-0.5">Specialties</div>
              <div className="text-[11px] text-slate-500">Under One Roof</div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
