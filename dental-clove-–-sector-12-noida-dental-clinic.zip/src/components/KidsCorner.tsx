import React from 'react';
import { Baby, Sparkles, Heart, Shield, CheckCircle, ArrowRight } from 'lucide-react';
import { handleImageError } from '../utils/imageFallback.ts';

interface KidsCornerProps {
  onOpenBooking: () => void;
}

export const KidsCorner: React.FC<KidsCornerProps> = ({ onOpenBooking }) => {
  const pillars = [
    {
      title: 'First Visit by Age 1 (or First Tooth)',
      desc: 'An easy, zero-fear "lap exam" where we count their teeth, check tongue ties, and advise parents on infant gum hygiene and night-feeding habits.',
      badge: 'Early Start',
    },
    {
      title: 'Our "Tell-Show-Do" Fear-Free Method',
      desc: 'No scary surprises! We explain every step in gentle, playful story language ("counting teeth with Mr. Mirror"), so your child feels safe and proud.',
      badge: 'Anxiety-Free',
    },
    {
      title: 'Cavity Prevention & Pit Sealants',
      desc: 'Safe fluoride varnishes and protective coatings that seal deep molar grooves to prevent cavities before they ever start.',
      badge: 'Long-term Shield',
    },
  ];

  return (
    <section id="kids-corner" className="py-20 bg-gradient-to-b from-sky-50/50 via-cyan-50/30 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-white via-sky-50/60 to-cyan-50/40 rounded-3xl p-8 sm:p-12 border border-sky-100 shadow-sm relative overflow-hidden">
          {/* Subtle playful decorative circles */}
          <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-cyan-100/50 blur-2xl pointer-events-none"></div>
          <div className="absolute -bottom-12 -left-12 w-48 h-48 rounded-full bg-sky-100/50 blur-2xl pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 text-sky-800 text-xs font-bold">
                <Baby className="w-4 h-4 text-sky-600" />
                <span>Parents' Guide to Paediatric Dentistry</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Little Smiles, Big Care: <br />
                <span className="text-sky-600">Gentle Kids&apos; Dental Care</span>
              </h2>

              <p className="text-slate-600 text-base leading-relaxed">
                A child&apos;s earliest dental memories shape how they care for their teeth for life. At Dental Clove, we take extra time to make every child feel celebrated, calm, and proud of their bright smile.
              </p>

              {/* 3 Pillars */}
              <div className="space-y-4 pt-2">
                {pillars.map((pillar, idx) => (
                  <div
                    key={idx}
                    className="bg-white/90 rounded-2xl p-4 border border-sky-100 shadow-2xs flex items-start gap-3.5 hover:border-sky-200 transition"
                  >
                    <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
                      {idx + 1}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-sm font-bold text-slate-900">{pillar.title}</h4>
                        <span className="text-[10px] font-semibold text-cyan-800 bg-cyan-100/80 px-2 py-0.5 rounded-full">
                          {pillar.badge}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{pillar.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-4">
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="w-full sm:w-auto bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-sm px-6 py-3 rounded-full shadow-md shadow-orange-500/20 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <span>Book Child's First Visit</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <div className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Sticker rewards & bravery diplomas for kids</span>
                </div>
              </div>
            </div>

            {/* Right Visual Image */}
            <div className="lg:col-span-5 relative flex justify-center">
              <div className="relative w-full max-w-sm">
                <div className="rounded-3xl overflow-hidden shadow-xl border-4 border-white aspect-4/5 bg-slate-100">
                  <img
                    src="/images/kids.jpg"
                    alt="Happy, smiling child with healthy clean teeth after gentle paediatric dental check-up at Dental Clove in Sector 12 Noida"
                    className="w-full h-full object-cover"
                    loading="lazy"
                    onError={(e) => handleImageError(e, 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&w=800&q=80')}
                  />
                </div>
                {/* Floating pill badge */}
                <div className="absolute -bottom-4 -right-2 sm:-right-4 bg-white border border-sky-100 rounded-2xl p-3 shadow-lg flex items-center gap-2.5">
                  <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                  <span className="text-xs font-bold text-slate-800">
                    Gentle, Unhurried Appointments
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
