import React from 'react';

export const Marquee: React.FC = () => {
  const items = [
    'Braces',
    'Aligners',
    'Implants',
    'Root Canal',
    'Whitening',
    'Kids Dentistry',
    'Check-ups',
  ];

  return (
    <div
      className="relative w-full overflow-hidden bg-[#e0f2fe] border-y border-sky-200/70 text-slate-900 py-4 shadow-xs select-none"
      aria-label="Treatment Specialties Marquee"
    >
      <div className="flex w-max animate-marquee">
        {/* Render twice for continuous infinite scroll loop */}
        {[0, 1].map((copyIndex) => (
          <div key={copyIndex} className="flex items-center space-x-6 sm:space-x-8 shrink-0 pr-6 sm:pr-8">
            {items.map((item, idx) => (
              <React.Fragment key={`${copyIndex}-${idx}`}>
                <span className="text-base sm:text-lg font-bold tracking-wider text-slate-800 hover:text-sky-700 transition">
                  {item}
                </span>
                <span className="text-sky-500 font-normal text-xl sm:text-2xl select-none" aria-hidden="true">
                  +
                </span>
              </React.Fragment>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
