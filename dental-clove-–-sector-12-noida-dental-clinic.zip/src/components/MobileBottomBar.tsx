import React from 'react';
import { Phone, ArrowRight } from 'lucide-react';

interface MobileBottomBarProps {
  onOpenBooking: () => void;
}

export const MobileBottomBar: React.FC<MobileBottomBarProps> = ({ onOpenBooking }) => {
  return (
    <aside
      aria-label="Quick mobile action bar"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 p-2.5 px-4 shadow-lg flex items-center gap-3"
    >
      <a
        href="tel:[PHONE +91]"
        className="flex-1 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 font-bold text-xs py-3 px-3 rounded-2xl flex items-center justify-center gap-2 border border-slate-200/80 transition"
        aria-label="Call clinic at [PHONE +91]"
      >
        <Phone className="w-4 h-4 text-sky-600" />
        <span>Call [PHONE +91]</span>
      </a>

      <button
        type="button"
        onClick={onOpenBooking}
        className="flex-1 bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-bold text-xs py-3 px-3 rounded-2xl shadow-md shadow-orange-500/20 flex items-center justify-center gap-1.5 transition cursor-pointer"
      >
        <span>Book Appointment</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </aside>
  );
};
