import React from 'react';
import { MapPin, Phone, Clock, Mail } from 'lucide-react';
import { CLINIC_NAP } from '../data/blogData.ts';

export const NapBlock: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div
      className={`rounded-2xl bg-white border border-slate-200/90 p-5 shadow-xs text-xs text-slate-600 ${className}`}
      itemScope
      itemType="https://schema.org/Dentist"
    >
      <div className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-1.5" itemProp="name">
        <span className="w-2 h-2 rounded-full bg-sky-600"></span>
        <span>{CLINIC_NAP.name} – Sector 12, Noida Dental Practice</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
        <div className="flex items-start gap-2" itemProp="address" itemScope itemType="https://schema.org/PostalAddress">
          <MapPin className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-800 block">Clinic Address</span>
            <span itemProp="streetAddress">{CLINIC_NAP.streetAddress}</span>,{' '}
            <span itemProp="addressLocality">{CLINIC_NAP.locality}</span>,{' '}
            <span itemProp="addressRegion">{CLINIC_NAP.region}</span>{' '}
            <span itemProp="postalCode">{CLINIC_NAP.postalCode}</span>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <Phone className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-800 block">Direct Contact</span>
            <a href={`tel:${CLINIC_NAP.phone}`} className="text-sky-700 hover:underline font-medium" itemProp="telephone">
              {CLINIC_NAP.phone}
            </a>
            <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
              <Mail className="w-3 h-3 text-slate-400" />
              <a href={`mailto:${CLINIC_NAP.email}`} className="hover:underline" itemProp="email">
                {CLINIC_NAP.email}
              </a>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <Clock className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-800 block">Consultation Hours</span>
            <span>{CLINIC_NAP.hours}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
        <span>Founded in {CLINIC_NAP.foundingDate} • Serving Sector 12, Sector 18, Sector 62, Noida Extension & Delhi NCR</span>
        <span className="text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded">
          Ground-Floor Clinic with Ramp & Reserved Parking
        </span>
      </div>
    </div>
  );
};
