import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, ArrowRight, Menu, X, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  const navLinks = [
    { name: 'Home', href: isHome ? '#home' : '/#home', isInternalRoute: false },
    { name: 'About', href: isHome ? '#about' : '/#about', isInternalRoute: false },
    { name: 'Treatments', href: isHome ? '#treatments' : '/#treatments', isInternalRoute: false },
    { name: 'Doctors', href: isHome ? '#doctors' : '/#doctors', isInternalRoute: false },
    { name: 'Reviews', href: isHome ? '#reviews' : '/#reviews', isInternalRoute: false },
    { name: 'Blog', href: '/blog', isInternalRoute: true },
    { name: 'Contact', href: isHome ? '#contact' : '/#contact', isInternalRoute: false },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-sky-100/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-2.5 group focus:outline-hidden focus:ring-2 focus:ring-sky-500 rounded-lg p-1"
            aria-label="Dental Clove Sector 12 Noida - Home"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-sky-600 flex items-center justify-center text-white shadow-sm shadow-sky-500/20 group-hover:scale-105 transition">
              <svg
                viewBox="0 0 24 24"
                className="w-6 h-6 fill-current"
                aria-hidden="true"
              >
                {/* Stylized Tooth & Leaf Clove mark */}
                <path d="M12 2C8.5 2 6 4.8 6 8.5c0 3 1.5 6.5 2.5 10 .8 2.8 1.8 3.5 3.5 3.5 1.7 0 2.7-.7 3.5-3.5 1-3.5 2.5-7 2.5-10C18 4.8 15.5 2 12 2zm-1 16.5c-.8 0-1.5-1.5-2.2-4.2C8 11.2 7.5 8.7 7.5 8.5 7.5 5.8 9.4 3.5 12 3.5s4.5 2.3 4.5 5c0 .2-.5 2.7-1.3 5.8-.7 2.7-1.4 4.2-2.2 4.2-.7 0-1.2-.8-1.5-2-.3 1.2-.8 2-1.5 2z" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-slate-900 group-hover:text-sky-700 transition">
                Dental Clove
              </span>
              <span className="text-[11px] font-medium text-sky-700 tracking-wide">
                Sector 12, Noida
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-7" aria-label="Main Navigation">
            {navLinks.map((link) =>
              link.isInternalRoute ? (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`text-sm font-semibold transition ${
                    location.pathname.startsWith('/blog')
                      ? 'text-sky-600 font-bold'
                      : 'text-slate-600 hover:text-sky-600'
                  }`}
                >
                  {link.name}
                </Link>
              ) : (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-sm font-semibold text-slate-600 hover:text-sky-600 transition"
                >
                  {link.name}
                </a>
              )
            )}
          </nav>

          {/* Header Action CTAs */}
          <div className="flex items-center gap-3">
            {/* Tap-to-call icon for mobile */}
            <a
              href="tel:[PHONE +91]"
              className="flex md:hidden items-center justify-center w-10 h-10 rounded-full bg-sky-50 text-sky-700 border border-sky-200/80 hover:bg-sky-100 transition active:scale-95"
              aria-label="Call Dental Clove clinic at [PHONE +91]"
            >
              <Phone className="w-4 h-4" />
            </a>

            {/* Desktop Call display */}
            <a
              href="tel:[PHONE +91]"
              className="hidden lg:flex items-center gap-2 text-sm font-bold text-slate-800 hover:text-sky-600 transition px-3 py-2 rounded-xl hover:bg-sky-50/60"
              aria-label="Call clinic directly"
            >
              <Phone className="w-4 h-4 text-sky-600" />
              <span>[PHONE +91]</span>
            </a>

            {/* Orange Pill CTA Button (Visible on sm+ screens, mobile has sticky bottom bar) */}
            <button
              type="button"
              onClick={onOpenBooking}
              className="hidden sm:flex bg-orange-500 hover:bg-orange-600 active:scale-95 text-white font-semibold text-sm px-5 py-2.5 rounded-full shadow-md shadow-orange-500/20 hover:shadow-orange-500/30 items-center gap-2 transition cursor-pointer"
            >
              <span>Book Appointment</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Mobile hamburger menu toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden flex items-center justify-center w-10 h-10 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-sky-100 px-4 pt-2 pb-6 shadow-lg animate-in fade-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-3" aria-label="Mobile Navigation">
            {navLinks.map((link) =>
              link.isInternalRoute ? (
                <Link
                  key={link.name}
                  to={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 rounded-lg text-base font-semibold text-slate-800 hover:bg-sky-50 hover:text-sky-600 transition"
                >
                  {link.name}
                </Link>
              ) : (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 rounded-lg text-base font-semibold text-slate-800 hover:bg-sky-50 hover:text-sky-600 transition"
                >
                  {link.name}
                </a>
              )
            )}

            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <a
                href="tel:[PHONE +91]"
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-sky-50 text-sky-800 font-bold text-sm"
              >
                <Phone className="w-4 h-4 text-sky-600" />
                <span>Call [PHONE +91]</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-sm text-sm"
              >
                <Sparkles className="w-4 h-4" />
                <span>Book Appointment</span>
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
