import React from 'react';
import { Star, ExternalLink, MapPin } from 'lucide-react';

export const PatientReviews: React.FC = () => {
  const reviews = [
    {
      id: 1,
      name: '[PATIENT NAME 1] – Sector 12 Resident',
      treatment: 'Root Canal Treatment & Crown',
      date: '2 months ago',
      content:
        '[REAL REVIEW 1: "Visited Dental Clove after dreading a root canal for weeks. The doctor was exceptionally gentle, explained the entire procedure before starting, and made sure I felt zero pain. Truly grateful for having such caring doctors right here in Sector 12 Noida."]',
      rating: 5,
    },
    {
      id: 2,
      name: '[PATIENT NAME 2] – Noida Resident',
      treatment: 'Clear Aligners Consultation',
      date: '1 month ago',
      content:
        '[REAL REVIEW 2: "Got my clear aligners done here. Extremely transparent about the entire duration and costs from day one without pushing unneeded packages. Clinic is spotless and very well maintained."]',
      rating: 5,
    },
    {
      id: 3,
      name: '[PATIENT NAME 3] – Parent from Sector 22',
      treatment: 'Paediatric Check-up & Cavity Filling',
      date: '3 weeks ago',
      content:
        '[REAL REVIEW 3: "Brought my 6-year-old daughter for her first tooth filling. The doctor was so patient and playful that she didn\'t cry even once! The best paediatric dental care experience in Noida."]',
      rating: 5,
    },
  ];

  return (
    <section id="reviews" className="py-20 bg-slate-50/80 border-y border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>Patient Experiences</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Trusted by Families in <span className="text-sky-600">Sector 12, Noida</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Real feedback from local residents who visited Dental Clove for their dental treatments.
          </p>
        </div>

        {/* 3 Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-white rounded-3xl p-7 border border-sky-100/90 shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                {/* 5-Star Rating */}
                <div className="flex items-center gap-1 mb-4" aria-label="5 out of 5 stars">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                  <span className="text-xs font-bold text-slate-700 ml-1.5">5.0</span>
                </div>

                {/* Review Body */}
                <p className="text-sm text-slate-700 leading-relaxed italic mb-6">
                  {rev.content}
                </p>
              </div>

              {/* Patient Footer */}
              <div className="pt-4 border-t border-slate-100">
                <div className="font-bold text-slate-900 text-sm">{rev.name}</div>
                <div className="text-xs text-sky-700 font-medium flex items-center justify-between mt-0.5">
                  <span>{rev.treatment}</span>
                  <span className="text-slate-400">{rev.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Read more on Google Link */}
        <div className="mt-12 text-center">
          <a
            href="[GOOGLE MAPS URL]"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm font-bold text-slate-800 bg-white hover:bg-slate-100 border border-slate-200/90 px-6 py-3 rounded-full shadow-xs transition"
          >
            <MapPin className="w-4 h-4 text-sky-600" />
            <span>Read more reviews on Google</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400 ml-1" />
          </a>
        </div>
      </div>
    </section>
  );
};
