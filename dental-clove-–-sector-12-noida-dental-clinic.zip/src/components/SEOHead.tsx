import { useEffect } from 'react';

export interface SEOHeadProps {
  title: string;
  description: string;
  canonicalPath: string;
  ogType?: 'website' | 'article';
  ogImage?: string;
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  jsonLd?: Record<string, unknown> | Array<Record<string, unknown>>;
}

const DEFAULT_SHARE_IMAGE =
  'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&h=630&q=80';
const BASE_DOMAIN = 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app';

export const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  canonicalPath,
  ogType = 'website',
  ogImage = DEFAULT_SHARE_IMAGE,
  publishedTime,
  modifiedTime,
  author,
  jsonLd,
}) => {
  useEffect(() => {
    // 1. Update Title tag
    document.title = title;

    // Helper to set or create meta tag by attribute
    const setMeta = (attr: string, key: string, content: string) => {
      let el = document.querySelector(`meta[${attr}="${key}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    // Helper to set or create link tag
    const setLink = (rel: string, href: string) => {
      let el = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
      if (!el) {
        el = document.createElement('link');
        el.setAttribute('rel', rel);
        document.head.appendChild(el);
      }
      el.setAttribute('href', href);
    };

    const origin =
      typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost')
        ? window.location.origin
        : BASE_DOMAIN;
    const fullCanonicalUrl = `${origin}${canonicalPath.startsWith('/') ? canonicalPath : `/${canonicalPath}`}`;

    // 2. Standard Meta Tags
    setMeta('name', 'description', description);
    setMeta('name', 'robots', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
    setLink('canonical', fullCanonicalUrl);

    const resolvedOgImage = ogImage.startsWith('http')
      ? ogImage
      : `${origin}${ogImage.startsWith('/') ? ogImage : `/${ogImage}`}`;

    // 3. OpenGraph Tags
    setMeta('property', 'og:title', title);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:type', ogType);
    setMeta('property', 'og:url', fullCanonicalUrl);
    setMeta('property', 'og:image', resolvedOgImage);
    setMeta('property', 'og:site_name', 'Dental Clove');
    setMeta('property', 'og:locale', 'en_IN');

    if (publishedTime) {
      setMeta('property', 'article:published_time', publishedTime);
    }
    if (modifiedTime) {
      setMeta('property', 'article:modified_time', modifiedTime);
    }
    if (author) {
      setMeta('property', 'article:author', author);
    }

    // 4. Twitter Card Tags
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', title);
    setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', resolvedOgImage);

    // 5. Schema.org JSON-LD Script Injection
    const SCRIPT_ID = 'applet-dynamic-jsonld';
    let scriptEl = document.getElementById(SCRIPT_ID) as HTMLScriptElement | null;
    if (jsonLd) {
      if (!scriptEl) {
        scriptEl = document.createElement('script');
        scriptEl.id = SCRIPT_ID;
        scriptEl.type = 'application/ld+json';
        document.head.appendChild(scriptEl);
      }
      scriptEl.textContent = JSON.stringify(jsonLd, null, 2);
    } else if (scriptEl) {
      scriptEl.remove();
    }

    // Scroll to top on navigation if needed
    window.scrollTo(0, 0);
  }, [title, description, canonicalPath, ogType, ogImage, publishedTime, modifiedTime, author, jsonLd]);

  return null;
};
