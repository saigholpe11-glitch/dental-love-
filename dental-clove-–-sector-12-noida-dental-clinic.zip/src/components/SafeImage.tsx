import React, { useState } from 'react';

export type ImageCategory = 'clinic' | 'doctor' | 'treatment' | 'smile' | 'kids' | 'article' | 'general';

interface SafeImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  category?: ImageCategory;
  fallbackSrc?: string;
  className?: string;
  priority?: boolean;
}

// Generate self-contained, high-resolution SVG fallbacks with dental branding
// These ensure that even if Unsplash or external CDNs are blocked by ISPs, ad-blockers,
// or strict referrer policies in production, the images will ALWAYS display crisply.
const createSvgFallback = (category: ImageCategory, label: string): string => {
  const configs: Record<
    ImageCategory,
    { bg1: string; bg2: string; iconPath: string; subtext: string }
  > = {
    clinic: {
      bg1: '#0284c7',
      bg2: '#0f172a',
      iconPath:
        'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm6-6h-3V7h-2v4H9V7H7v6h10v-2z',
      subtext: 'Modern Sterilised Operatory • Sector 12, Noida',
    },
    doctor: {
      bg1: '#0369a1',
      bg2: '#1e293b',
      iconPath:
        'M12 2C8.5 2 6 4.8 6 8.5c0 3 1.5 6.5 2.5 10 .8 2.8 1.8 3.5 3.5 3.5 1.7 0 2.7-.7 3.5-3.5 1-3.5 2.5-7 2.5-10C18 4.8 15.5 2 12 2zm0 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z',
      subtext: 'Resident Dental Specialist • Dental Clove',
    },
    treatment: {
      bg1: '#0891b2',
      bg2: '#0e7490',
      iconPath:
        'M12 2C8.5 2 6 4.8 6 8.5c0 3 1.5 6.5 2.5 10 .8 2.8 1.8 3.5 3.5 3.5 1.7 0 2.7-.7 3.5-3.5 1-3.5 2.5-7 2.5-10C18 4.8 15.5 2 12 2z',
      subtext: 'Gentle & Comprehensive Treatment',
    },
    smile: {
      bg1: '#0ea5e9',
      bg2: '#0369a1',
      iconPath:
        'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-5-9c.83 0 1.5-.67 1.5-1.5S7.83 8 7 8s-1.5.67-1.5 1.5S6.17 11 7 11zm10 0c.83 0 1.5-.67 1.5-1.5S17.83 8 17 8s-1.5.67-1.5 1.5.67 1.5 1.5 1.5zm-5 6c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z',
      subtext: 'Healthy Aligned Smiles • Sector 12, Noida',
    },
    kids: {
      bg1: '#f59e0b',
      bg2: '#0284c7',
      iconPath:
        'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 14h-2v-2h2v2zm0-4h-2V7h2v5z',
      subtext: 'Gentle, Fear-Free Paediatric Dental Care',
    },
    article: {
      bg1: '#1e293b',
      bg2: '#0369a1',
      iconPath:
        'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z',
      subtext: 'Evidence-Based Dental Guide • Dental Clove',
    },
    general: {
      bg1: '#0284c7',
      bg2: '#0f172a',
      iconPath:
        'M12 2C8.5 2 6 4.8 6 8.5c0 3 1.5 6.5 2.5 10 .8 2.8 1.8 3.5 3.5 3.5 1.7 0 2.7-.7 3.5-3.5 1-3.5 2.5-7 2.5-10C18 4.8 15.5 2 12 2z',
      subtext: 'Dental Clove • Sector 12, Noida',
    },
  };

  const cfg = configs[category] || configs.general;
  const safeLabel = label ? label.slice(0, 48) : 'Dental Clove';

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${cfg.bg1}" />
        <stop offset="100%" stop-color="${cfg.bg2}" />
      </linearGradient>
      <radialGradient id="r" cx="50%" cy="30%" r="60%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.18" />
        <stop offset="100%" stop-color="#000000" stop-opacity="0.45" />
      </radialGradient>
    </defs>
    <rect width="800" height="600" fill="url(#g)" />
    <rect width="800" height="600" fill="url(#r)" />
    
    <!-- Stylized Tooth / Medical Watermark -->
    <g transform="translate(400, 240) scale(4.5)" fill="#ffffff" fill-opacity="0.22" stroke="none">
      <path d="${cfg.iconPath}" transform="translate(-12, -12)" />
    </g>

    <!-- Clinic Title & Badge -->
    <g transform="translate(400, 390)" text-anchor="middle">
      <rect x="-180" y="-32" width="360" height="42" rx="21" fill="#ffffff" fill-opacity="0.12" stroke="#ffffff" stroke-opacity="0.25" stroke-width="1.5" />
      <text y="-5" font-family="system-ui, -apple-system, sans-serif" font-size="20" font-weight="800" fill="#ffffff" letter-spacing="0.5">${safeLabel}</text>
      <text y="36" font-family="system-ui, -apple-system, sans-serif" font-size="15" font-weight="500" fill="#93c5fd" opacity="0.95">${cfg.subtext}</text>
      <text y="62" font-family="system-ui, -apple-system, sans-serif" font-size="13" font-weight="600" fill="#ffffff" opacity="0.75">Dental Clove • Sector 12, Noida</text>
    </g>
  </svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  category = 'general',
  fallbackSrc,
  className = '',
  priority = false,
  ...props
}) => {
  const [currentSrc, setCurrentSrc] = useState<string>(src);
  const [hasFailed, setHasFailed] = useState<boolean>(false);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // If the initial src changes from props, reset state
  React.useEffect(() => {
    setCurrentSrc(src);
    setHasFailed(false);
  }, [src]);

  const handleError = () => {
    if (!hasFailed) {
      setHasFailed(true);
      // Use custom fallback if provided, otherwise our rich dental SVG fallback
      const fallback = fallbackSrc || createSvgFallback(category, alt);
      setCurrentSrc(fallback);
    }
  };

  const handleLoad = () => {
    setIsLoaded(true);
  };

  return (
    <img
      {...props}
      src={currentSrc}
      alt={alt}
      // Critical for live production: prevents cross-origin hotlink blocks by external CDNs
      referrerPolicy="no-referrer"
      crossOrigin="anonymous"
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      onError={handleError}
      onLoad={handleLoad}
      className={`transition-opacity duration-300 ${
        isLoaded ? 'opacity-100' : 'opacity-90'
      } ${className}`}
    />
  );
};
