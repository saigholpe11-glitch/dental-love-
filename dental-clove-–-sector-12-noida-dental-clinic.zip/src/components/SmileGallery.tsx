import React, { useState } from 'react';
import { Sparkles, SlidersHorizontal, Info } from 'lucide-react';
import { handleImageError } from '../utils/imageFallback.ts';

interface GalleryCase {
  id: string;
  title: string;
  treatment: string;
  duration: string;
  beforeImg: string;
  afterImg: string;
  beforeFallback: string;
  afterFallback: string;
  description: string;
}

export const SmileGallery: React.FC = () => {
  const cases: GalleryCase[] = [
    {
      id: 'case-1',
      title: 'Smile Brightening',
      treatment: 'In-Clinic Teeth Whitening',
      duration: 'Single 45-Minute Visit',
      beforeImg: '/images/dental-chair.jpg',
      afterImg: '/images/hero.jpg',
      beforeFallback: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
      afterFallback: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=800&q=80',
      description: 'Removal of stubborn coffee, tea, and tobacco stains using safe enamel-friendly LED light activation.',
    },
    {
      id: 'case-2',
      title: 'Discreet Tooth Realignment',
      treatment: 'Clear Aligners Therapy',
      duration: '9 Months Duration',
      beforeImg: '/images/patient-smile.jpg',
      afterImg: '/images/aligners-smile.jpg',
      beforeFallback: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=800&q=80',
      afterFallback: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80',
      description: 'Correction of anterior crowding and midline space with 18 sets of transparent aligners.',
    },
    {
      id: 'case-3',
      title: 'Tooth Replacement & Function',
      treatment: 'Dental Implant & Zirconia Crown',
      duration: 'Completed in 3 Months',
      beforeImg: '/images/operatory.jpg',
      afterImg: '/images/doctor1.jpg',
      beforeFallback: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80',
      afterFallback: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=800&q=80',
      description: 'Replacement of a fractured premolar restoring full chewing power and natural emergence profile.',
    },
  ];

  const [selectedCaseIdx, setSelectedCaseIdx] = useState(0);
  const [sliderPos, setSliderPos] = useState(50); // percentage 0 to 100

  const activeCase = cases[selectedCaseIdx];

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSliderPos(Number(e.target.value));
  };

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinical Outcomes</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Smile <span className="text-sky-600">Gallery</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Drag the slider across each case to view representative before and after transformations.
          </p>

          {/* Case Selector Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            {cases.map((c, i) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCaseIdx(i)}
                className={`px-4 py-2 rounded-full text-xs font-bold transition cursor-pointer ${
                  selectedCaseIdx === i
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {c.treatment}
              </button>
            ))}
          </div>
        </div>

        {/* Interactive Before/After Split Viewer */}
        <div className="max-w-3xl mx-auto bg-slate-50 border border-sky-100 rounded-3xl p-4 sm:p-8 shadow-sm">
          <div className="relative aspect-16/10 rounded-2xl overflow-hidden shadow-inner select-none bg-slate-200">
            {/* After Image (Background) */}
            <img
              src={activeCase.afterImg}
              alt={`Clinical outcome after ${activeCase.treatment} for ${activeCase.title} at Dental Clove in Sector 12 Noida`}
              className="absolute inset-0 w-full h-full object-cover"
              loading="lazy"
              onError={(e) => handleImageError(e, activeCase.afterFallback)}
            />
            <div className="absolute top-4 right-4 bg-emerald-600/90 text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-xs">
              After Treatment
            </div>

            {/* Before Image (Clipped Overlay) */}
            <div
              className="absolute inset-y-0 left-0 overflow-hidden"
              style={{ width: `${sliderPos}%` }}
            >
              <img
                src={activeCase.beforeImg}
                alt={`Clinical condition before ${activeCase.treatment} for ${activeCase.title} at Dental Clove in Sector 12 Noida`}
                className="absolute inset-0 w-full h-full object-cover max-w-none"
                style={{ width: '100%', minWidth: '100%' }}
                loading="lazy"
                onError={(e) => handleImageError(e, activeCase.beforeFallback)}
              />
              <div className="absolute top-4 left-4 bg-slate-900/80 text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-xs">
                Before
              </div>
            </div>

            {/* Divider Line & Slider Handle */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-white shadow-lg pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-xl flex items-center justify-center text-slate-800 border-2 border-sky-500">
                <SlidersHorizontal className="w-4 h-4 text-sky-600" />
              </div>
            </div>

            {/* Native Range Input for drag & keyboard accessibility */}
            <input
              type="range"
              min="0"
              max="100"
              value={sliderPos}
              onChange={handleSliderChange}
              aria-label="Drag before and after split slider"
              className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-30"
            />
          </div>

          {/* Case Metadata */}
          <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-t border-slate-200/80 pt-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">{activeCase.title}</h3>
              <p className="text-xs text-slate-600 mt-0.5">{activeCase.description}</p>
            </div>
            <div className="shrink-0 bg-white border border-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700">
              {activeCase.duration}
            </div>
          </div>

          {/* Mandatory note requested by prompt */}
          <div className="mt-6 pt-4 border-t border-slate-200/60 flex items-center justify-center gap-2 text-xs text-slate-500 text-center font-medium">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            <span>Results vary. Shared with patient consent.</span>
          </div>
        </div>
      </div>
    </section>
  );
};
