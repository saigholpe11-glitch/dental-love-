import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Eye, Layers, RotateCw, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';

interface ThreeToothViewerProps {
  className?: string;
}

export const ThreeToothViewer: React.FC<ThreeToothViewerProps> = ({ className = '' }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [controlsOpen, setControlsOpen] = useState(true);
  const [alignerMode, setAlignerMode] = useState<'fitted' | 'elevated' | 'hidden'>('fitted');
  const [viewPreset, setViewPreset] = useState<'front' | 'angled' | 'top'>('angled');
  const [isRotating, setIsRotating] = useState(true);
  const [displayMode, setDisplayMode] = useState<'natural' | 'xray'>('natural');

  // Mutable refs for Three.js render loop
  const stateRef = useRef({
    alignerMode: 'fitted',
    viewPreset: 'angled',
    isRotating: true,
    displayMode: 'natural',
    targetYAligner: 0,
    currentYAligner: 0,
    targetRotY: 0.35,
    targetRotX: 0.15,
    pointerDown: false,
    prevPointerX: 0,
    prevPointerY: 0,
  });

  // Keep stateRef in sync with React state
  useEffect(() => {
    stateRef.current.alignerMode = alignerMode;
    stateRef.current.isRotating = isRotating;
    stateRef.current.displayMode = displayMode;
    stateRef.current.viewPreset = viewPreset;

    if (alignerMode === 'fitted') stateRef.current.targetYAligner = 0;
    else if (alignerMode === 'elevated') stateRef.current.targetYAligner = 0.85;
    else stateRef.current.targetYAligner = 2.5;

    if (viewPreset === 'front') {
      stateRef.current.targetRotY = 0;
      stateRef.current.targetRotX = 0.05;
    } else if (viewPreset === 'angled') {
      stateRef.current.targetRotY = 0.65;
      stateRef.current.targetRotX = 0.2;
    } else if (viewPreset === 'top') {
      stateRef.current.targetRotY = 0;
      stateRef.current.targetRotX = 0.85;
    }
  }, [alignerMode, isRotating, displayMode, viewPreset]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;

    const isHeadless =
      typeof navigator !== 'undefined' &&
      (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0.6, 4.6);

    // 2. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isHeadless,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(isHeadless ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isHeadless;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 3. Studio Environment Map (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 4. Lighting Rig (Warm Key Light, Cool Fill, Rim)
    const keyLight = new THREE.DirectionalLight(0xfff8f0, 2.2);
    keyLight.position.set(3, 4, 3);
    keyLight.castShadow = !isHeadless;
    keyLight.shadow.mapSize.width = 512;
    keyLight.shadow.mapSize.height = 512;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xe0f2fe, 1.2);
    fillLight.position.set(-3, 2, -1);
    scene.add(fillLight);

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xe2e8f0, 0.8);
    scene.add(hemiLight);

    // 5. Contact Shadow (Procedural HTML5 Canvas)
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(64, 64, 0, 64, 64, 60);
      grad.addColorStop(0, 'rgba(15, 23, 42, 0.45)');
      grad.addColorStop(0.5, 'rgba(15, 23, 42, 0.15)');
      grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 128, 128);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    shadowTexture.colorSpace = THREE.SRGBColorSpace;

    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.4, 2.4),
      new THREE.MeshBasicMaterial({
        map: shadowTexture,
        transparent: true,
        depthWrite: false,
        opacity: 0.6,
      })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = -1.18;
    scene.add(contactShadow);

    // 6. Tooth & Aligner Composite Group (3–12 parts)
    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    // Part 1: Crown (Glossy Dental Enamel)
    const crownMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xfbfbfb,
      roughness: 0.18,
      metalness: 0.05,
      clearcoat: 0.9,
      clearcoatRoughness: 0.12,
      ior: 1.62,
    });

    const crownGeo = new THREE.CylinderGeometry(0.72, 0.58, 0.85, 32, 8);
    // Sculpt subtle cusps into crown geometry
    const pos = crownGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      const x = pos.getX(i);
      const z = pos.getZ(i);
      if (y > 0.2) {
        // Cusp peaks
        const cusp = Math.sin(x * 4.5) * Math.cos(z * 4.5) * 0.08;
        pos.setY(i, y + cusp);
      }
    }
    crownGeo.computeVertexNormals();

    const crownMesh = new THREE.Mesh(crownGeo, crownMaterial);
    crownMesh.position.y = 0.1;
    crownMesh.castShadow = !isHeadless;
    crownMesh.receiveShadow = !isHeadless;
    rootGroup.add(crownMesh);

    // Part 2: Inner Dentin Core (Visible in X-ray mode)
    const dentinMaterial = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      roughness: 0.5,
      metalness: 0.0,
      transparent: true,
      opacity: 0.0,
    });
    const dentinMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.4, 0.7, 24),
      dentinMaterial
    );
    dentinMesh.position.y = 0.08;
    rootGroup.add(dentinMesh);

    // Part 3 & 4: Dual Anatomical Roots
    const rootMaterial = new THREE.MeshStandardMaterial({
      color: 0xfef3c7,
      roughness: 0.38,
      metalness: 0.02,
    });

    const rootCurve1 = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.25, -0.3, 0),
      new THREE.Vector3(-0.35, -0.75, 0.05),
      new THREE.Vector3(-0.3, -1.15, 0.02),
    ]);
    const rootGeo1 = new THREE.TubeGeometry(rootCurve1, 24, 0.18, 16, false);
    const rootMesh1 = new THREE.Mesh(rootGeo1, rootMaterial);
    rootMesh1.castShadow = !isHeadless;
    rootGroup.add(rootMesh1);

    const rootCurve2 = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.25, -0.3, 0),
      new THREE.Vector3(0.35, -0.75, -0.05),
      new THREE.Vector3(0.28, -1.15, -0.02),
    ]);
    const rootGeo2 = new THREE.TubeGeometry(rootCurve2, 24, 0.18, 16, false);
    const rootMesh2 = new THREE.Mesh(rootGeo2, rootMaterial);
    rootMesh2.castShadow = !isHeadless;
    rootGroup.add(rootMesh2);

    // Part 5: Gingival / Gum Base Tissue Collar
    const gumMaterial = new THREE.MeshStandardMaterial({
      color: 0xf472b6,
      roughness: 0.55,
      metalness: 0.0,
    });
    const gumGeo = new THREE.TorusGeometry(0.64, 0.14, 16, 32);
    const gumMesh = new THREE.Mesh(gumGeo, gumMaterial);
    gumMesh.rotation.x = Math.PI / 2;
    gumMesh.position.y = -0.34;
    rootGroup.add(gumMesh);

    // Part 6: Orthodontic Composite Attachment Button
    const attachmentMaterial = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.25,
      metalness: 0.4,
    });
    const attachmentMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.16, 0.08),
      attachmentMaterial
    );
    attachmentMesh.position.set(0, 0.15, 0.72);
    rootGroup.add(attachmentMesh);

    // Part 7: Clear Orthodontic Aligner Sleeve
    const alignerGroup = new THREE.Group();
    rootGroup.add(alignerGroup);

    const alignerMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.94,
      opacity: 0.9,
      transparent: true,
      roughness: 0.05,
      ior: 1.52,
      thickness: 0.6,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    const alignerGeo = new THREE.CylinderGeometry(0.79, 0.66, 0.95, 32, 4, true);
    const alignerMesh = new THREE.Mesh(alignerGeo, alignerMaterial);
    alignerMesh.position.y = 0.12;
    alignerGroup.add(alignerMesh);

    // Top rim of aligner
    const alignerRimGeo = new THREE.TorusGeometry(0.79, 0.03, 12, 32);
    const alignerRimMesh = new THREE.Mesh(alignerRimGeo, alignerMaterial);
    alignerRimMesh.rotation.x = Math.PI / 2;
    alignerRimMesh.position.y = 0.58;
    alignerGroup.add(alignerRimMesh);

    // Part 8: Aligner Accent Border
    const alignerBorderGeo = new THREE.TorusGeometry(0.66, 0.025, 12, 32);
    const alignerBorderMesh = new THREE.Mesh(alignerBorderGeo, alignerMaterial);
    alignerBorderMesh.rotation.x = Math.PI / 2;
    alignerBorderMesh.position.y = -0.35;
    alignerGroup.add(alignerBorderMesh);

    // Pre-warm renderer
    renderer.compile(scene, camera);

    // Pointer interaction handling for manual rotation
    const handlePointerDown = (e: PointerEvent) => {
      stateRef.current.pointerDown = true;
      stateRef.current.prevPointerX = e.clientX;
      stateRef.current.prevPointerY = e.clientY;
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!stateRef.current.pointerDown) return;
      const dx = e.clientX - stateRef.current.prevPointerX;
      const dy = e.clientY - stateRef.current.prevPointerY;
      stateRef.current.prevPointerX = e.clientX;
      stateRef.current.prevPointerY = e.clientY;

      stateRef.current.targetRotY += dx * 0.008;
      stateRef.current.targetRotX = Math.max(
        -0.4,
        Math.min(0.9, stateRef.current.targetRotX + dy * 0.008)
      );
    };

    const handlePointerUp = () => {
      stateRef.current.pointerDown = false;
    };

    const dom = renderer.domElement;
    dom.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    // Animation Loop with Exponential Damping
    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      // In headless software WebGL, throttle loop to ~15fps
      if (isHeadless && time - lastTime < 65) {
        animId = requestAnimationFrame(animate);
        return;
      }
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      // Auto-rotation if enabled & not dragging
      if (stateRef.current.isRotating && !stateRef.current.pointerDown) {
        stateRef.current.targetRotY += 0.4 * dt;
      }

      // Smooth damping on group rotation
      const dampFactor = 1 - Math.exp(-8 * dt);
      rootGroup.rotation.y += (stateRef.current.targetRotY - rootGroup.rotation.y) * dampFactor;
      rootGroup.rotation.x += (stateRef.current.targetRotX - rootGroup.rotation.x) * dampFactor;

      // Smooth damping on Aligner vertical translation
      stateRef.current.currentYAligner +=
        (stateRef.current.targetYAligner - stateRef.current.currentYAligner) * dampFactor;
      alignerGroup.position.y = stateRef.current.currentYAligner;

      // Hide aligner if in hidden mode
      const isHidden = stateRef.current.alignerMode === 'hidden';
      alignerGroup.visible = !isHidden || stateRef.current.currentYAligner < 2.0;
      alignerMaterial.opacity = isHidden ? Math.max(0, 1 - stateRef.current.currentYAligner / 2) : 0.92;

      // Display mode adjustments (X-ray vs Natural)
      if (stateRef.current.displayMode === 'xray') {
        crownMaterial.transparent = true;
        crownMaterial.opacity = 0.35;
        dentinMaterial.opacity = 0.85;
      } else {
        crownMaterial.transparent = false;
        crownMaterial.opacity = 1.0;
        dentinMaterial.opacity = 0.0;
      }

      renderer.render(scene, camera);
      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);

    // Resize observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w === 0 || h === 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const ro = new ResizeObserver(handleResize);
    ro.observe(container);

    return () => {
      cancelAnimationFrame(animId);
      ro.disconnect();
      dom.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
      crownGeo.dispose();
      crownMaterial.dispose();
      dentinMesh.geometry.dispose();
      dentinMaterial.dispose();
      rootGeo1.dispose();
      rootGeo2.dispose();
      rootMaterial.dispose();
      gumGeo.dispose();
      gumMaterial.dispose();
      alignerGeo.dispose();
      alignerRimGeo.dispose();
      alignerBorderGeo.dispose();
      alignerMaterial.dispose();
      attachmentMesh.geometry.dispose();
      attachmentMaterial.dispose();
      shadowTexture.dispose();
      contactShadow.geometry.dispose();
    };
  }, []);

  return (
    <div
      className={`relative w-full rounded-3xl overflow-hidden bg-gradient-to-b from-sky-50/70 via-white to-blue-50/40 border border-sky-100/80 shadow-inner flex flex-col justify-between ${className}`}
      style={{ minHeight: '440px' }}
      data-testid="three-tooth-viewer"
    >
      {/* 3D Scene Top Badge (Static, no pulsating dots) */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-white/90 backdrop-blur-none border border-sky-200/80 px-3.5 py-1.5 rounded-full shadow-xs text-xs font-semibold text-slate-700">
        <Sparkles className="w-3.5 h-3.5 text-sky-600" />
        <span>3D Clear Aligner & Tooth Explorer</span>
        <span className="text-[10px] text-sky-700 bg-sky-100 font-bold px-1.5 py-0.5 rounded">
          Interactive
        </span>
      </div>

      {/* Rotation hint badge */}
      <div className="absolute top-4 right-4 z-10 hidden sm:flex items-center gap-1.5 bg-white/80 border border-slate-200/60 px-3 py-1 rounded-full text-[11px] text-slate-500 font-medium shadow-xs">
        <span>Drag to rotate 360°</span>
      </div>

      {/* WebGL Canvas Container */}
      <div
        ref={mountRef}
        className="w-full flex-1 cursor-grab active:cursor-grabbing touch-none min-h-[340px]"
        aria-label="Interactive 3D simulation of clear aligner and tooth anatomy"
      />

      {/* Collapsible Unified Bottom Control Dock (Directly adhering to Three.js skill layout directives) */}
      <div className="relative z-20 w-full px-3 pb-3">
        {/* Toggle Collapse Button */}
        <div className="flex justify-center -mb-2 relative z-30">
          <button
            type="button"
            onClick={() => setControlsOpen(!controlsOpen)}
            className="flex items-center gap-1 bg-white border border-slate-200/90 text-[11px] font-medium text-slate-600 px-3 py-1 rounded-full shadow-xs hover:bg-slate-50 transition"
            aria-label={controlsOpen ? 'Collapse 3D controls' : 'Show 3D controls'}
          >
            {controlsOpen ? (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                <span>Hide Controls</span>
              </>
            ) : (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
                <span>Show 3D Controls</span>
              </>
            )}
          </button>
        </div>

        {/* Unified Bottom Dock */}
        {controlsOpen && (
          <div className="bg-white border border-sky-100 rounded-2xl p-2.5 sm:p-3 shadow-md max-w-2xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
            {/* Aligner state pills */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <span className="text-[11px] font-semibold text-slate-500 px-2 hidden sm:inline">
                Aligner:
              </span>
              <button
                type="button"
                onClick={() => setAlignerMode('fitted')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  alignerMode === 'fitted'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Fitted
              </button>
              <button
                type="button"
                onClick={() => setAlignerMode('elevated')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  alignerMode === 'elevated'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Lifted
              </button>
              <button
                type="button"
                onClick={() => setAlignerMode('hidden')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  alignerMode === 'hidden'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Tooth Only
              </button>
            </div>

            {/* View Angle and X-ray buttons */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() =>
                  setDisplayMode(displayMode === 'natural' ? 'xray' : 'natural')
                }
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition ${
                  displayMode === 'xray'
                    ? 'bg-amber-50 text-amber-800 border-amber-300'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title="Toggle Internal Anatomy / X-ray View"
              >
                <Layers className="w-3.5 h-3.5 text-sky-600" />
                <span className="hidden xs:inline">{displayMode === 'xray' ? 'Enamel View' : 'X-Ray Core'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsRotating(!isRotating)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition ${
                  isRotating
                    ? 'bg-sky-50 text-sky-700 border-sky-300'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title="Toggle Auto Rotation"
              >
                <RotateCw className="w-3.5 h-3.5 text-sky-600" />
                <span className="hidden xs:inline">{isRotating ? 'Rotating' : 'Paused'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextPreset =
                    viewPreset === 'angled'
                      ? 'front'
                      : viewPreset === 'front'
                      ? 'top'
                      : 'angled';
                  setViewPreset(nextPreset);
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 font-medium transition"
                title="Cycle Camera Angle"
              >
                <Eye className="w-3.5 h-3.5 text-sky-600" />
                <span className="capitalize">{viewPreset}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
