import React, { useState } from 'react';
import {
  Sparkles,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Shield,
  Smile,
  Zap,
  Activity,
  Sun,
  Baby,
  Clock,
  Tag,
} from 'lucide-react';

interface TreatmentsProps {
  onSelectTreatment: (treatmentName: string) => void;
}

interface TreatmentItem {
  id: string;
  name: string;
  tagline: string;
  directAnswer: string; // Direct 1-2 sentence AI-citable standalone answer
  durationFact: string; // Concrete duration/sitting fact
  costFact: string; // Transparent ₹[CLINIC PRICE]
  features: string[];
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
}

export const Treatments: React.FC<TreatmentsProps> = ({ onSelectTreatment }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const treatmentItems: TreatmentItem[] = [
    {
      id: 'general-dentistry',
      name: 'General Dentistry',
      tagline: 'Routine check-ups, deep cleaning, and tooth-saving composite fillings.',
      directAnswer:
        'General dental check-ups and ultrasonic scaling maintain long-term gum health and detect enamel cavities early before they cause pain. In Sector 12, Noida, our preventive visits take 30 to 45 minutes with tooth restorations starting from ₹[CLINIC PRICE].',
      durationFact: '30–45 mins per session • 6-month preventive frequency',
      costFact: 'Starting from ₹[CLINIC PRICE]',
      features: ['Ultrasonic scaling & stain removal', 'Tooth-coloured composite restorations', 'Gum health & digital X-ray screening'],
      icon: Smile,
      accentColor: 'from-sky-500/10 to-blue-500/10 text-sky-600',
    },
    {
      id: 'root-canal',
      name: 'Root Canal Treatment',
      tagline: 'Gentle, pain-relieving procedure to save infected or severely damaged teeth.',
      directAnswer:
        'A root canal removes inflamed or infected pulp tissue to relieve acute toothache and permanently save the natural tooth root. At Dental Clove, rotary endodontic treatments take 1 to 2 sittings of 45 to 60 minutes each, with fees starting at ₹[CLINIC PRICE] per tooth.',
      durationFact: '1–2 sittings of 45–60 mins • Crown placed in 7–10 days',
      costFact: 'Starting from ₹[CLINIC PRICE]',
      features: ['Rotary endodontics with digital apex locators', 'Profound pain-free local anaesthesia', 'High-strength protective crowns (Zirconia/PFM)'],
      icon: Zap,
      accentColor: 'from-amber-500/10 to-orange-500/10 text-amber-600',
    },
    {
      id: 'braces',
      name: 'Braces',
      tagline: 'Reliable orthodontic correction for crooked teeth and complex bites.',
      directAnswer:
        'Orthodontic braces utilize fixed brackets and memory wires to gradually guide crowded, spaced, or rotated teeth into optimal functional alignment. Treatment lasts 12 to 24 months with customized plans starting from ₹[CLINIC PRICE] and 0% EMI options in Noida.',
      durationFact: '12–24 months active duration • Monthly 20-min adjustments',
      costFact: 'Starting from ₹[CLINIC PRICE] (0% EMI available)',
      features: ['High-grade metal and tooth-toned ceramic brackets', 'Treats deep bites, crossbites, and severe crowding', 'Dedicated orthodontist monitoring every 4 weeks'],
      icon: Shield,
      accentColor: 'from-indigo-500/10 to-sky-500/10 text-indigo-600',
    },
    {
      id: 'clear-aligners',
      name: 'Clear Aligners',
      tagline: 'Invisible, custom-moulded removable trays to straighten your smile discreetly.',
      directAnswer:
        'Clear aligners are custom-fabricated transparent polymer trays that straighten teeth discreetly without metal wires or food restrictions. Treatment typically takes 6 to 18 months, with digital 3D simulations and packages starting from ₹[CLINIC PRICE] in Sector 12, Noida.',
      durationFact: '6–18 months • 20–22 hours daily wear • Trays change every 10–14 days',
      costFact: 'Starting from ₹[CLINIC PRICE] (Flexible monthly EMI)',
      features: ['Near-invisible medical-grade plastic', 'Removable for brushing, flossing, and dining', 'Predictable 3D digital simulation before fabrication'],
      icon: Sparkles,
      accentColor: 'from-cyan-500/10 to-sky-500/10 text-cyan-600',
    },
    {
      id: 'dental-implants',
      name: 'Dental Implants',
      tagline: 'Permanent, natural-feeling replacements for single or multiple missing teeth.',
      directAnswer:
        'Dental implants are biocompatible titanium posts anchored into the jawbone to permanently replace missing tooth roots and preserve bone structure. Complete restorations take 3 to 6 months across 2 stages, engineered to last 20 to 25+ years, starting from ₹[CLINIC PRICE].',
      durationFact: '3–6 months for osseointegration • 20–25+ years lifespan',
      costFact: 'Starting from ₹[CLINIC PRICE] per tooth',
      features: ['Titanium fixtures with high osseointegration success (>95%)', 'Prevents adjacent jawbone loss & facial collapse', 'No damage or grinding to adjacent healthy teeth'],
      icon: Activity,
      accentColor: 'from-blue-500/10 to-indigo-500/10 text-blue-600',
    },
    {
      id: 'teeth-whitening',
      name: 'Teeth Whitening',
      tagline: 'Safe, enamel-friendly in-clinic sessions to brighten dull or stained teeth.',
      directAnswer:
        'In-clinic teeth whitening uses dentist-supervised bleaching gel and safe LED light activation to lift stubborn coffee, tea, and ageing stains safely. A single 45-minute appointment brightens teeth by 3 to 6 shades, starting from ₹[CLINIC PRICE] in Sector 12, Noida.',
      durationFact: 'Single 45-minute clinic visit • Results last 12–24 months',
      costFact: 'Starting from ₹[CLINIC PRICE]',
      features: ['Enamel-friendly desensitising formula', 'Lifts deep intrinsic stains without erosion', 'Immediate radiant results for upcoming special events'],
      icon: Sun,
      accentColor: 'from-amber-400/10 to-yellow-500/10 text-amber-500',
    },
    {
      id: 'paediatric-dentistry',
      name: 'Paediatric Dentistry',
      tagline: 'Gentle, zero-fear dental care and cavity prevention designed just for kids.',
      directAnswer:
        'Paediatric dentistry at Dental Clove provides anxiety-free check-ups, habit counselling, and fluoride coatings to protect growing children from tooth decay. Routine infant and child visits take 25 to 35 minutes, with preventive fluoride coatings starting from ₹[CLINIC PRICE].',
      durationFact: '25–35 mins unhurried session • First visit by age 1 or first tooth',
      costFact: 'Starting from ₹[CLINIC PRICE]',
      features: ['"Tell-Show-Do" playful reassurance', 'Pit & fissure sealants for molar protection', 'Painless cavity fillings & child habit guidance'],
      icon: Baby,
      accentColor: 'from-teal-500/10 to-emerald-500/10 text-teal-600',
    },
  ];

  return (
    <section id="treatments" className="py-20 bg-slate-50 border-t border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading with Clear Standalone Context */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <span>Comprehensive Care in Sector 12, Noida</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            7 Essential Treatments <span className="text-sky-600">Under One Roof</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Dental Clove provides 7 core dental specialties with hospital-grade sterilisation, unhurried consultations,
            and transparent pricing for patients visiting from Sector 12, Sector 18, Sector 62, Noida Extension, and
            Delhi NCR.
          </p>
        </div>

        {/* 7 Treatment Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {treatmentItems.map((item) => {
            const isExpanded = expandedId === item.id;
            const IconComponent = item.icon;

            return (
              <div
                key={item.id}
                className="bg-white rounded-3xl p-6 sm:p-7 border border-sky-100 shadow-sm hover:shadow-md hover:border-sky-300 transition duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Outline-style Icon in soft rounded badge */}
                  <div
                    className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${item.accentColor} flex items-center justify-center border border-slate-100 shadow-2xs group-hover:scale-105 transition`}
                  >
                    <IconComponent className="w-6 h-6 stroke-[1.75]" />
                  </div>

                  {/* Title & Tagline */}
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 tracking-tight">{item.name}</h3>
                    <p className="text-xs sm:text-sm text-slate-500 mt-1 leading-snug">{item.tagline}</p>
                  </div>

                  {/* Direct Standalone Answer / Overview */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pt-1">
                    {item.directAnswer}
                  </p>

                  {/* Concrete Duration & Cost Facts */}
                  <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-500">
                    <div className="flex items-center gap-1.5 font-medium text-slate-700">
                      <Clock className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                      <span>{item.durationFact}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-semibold text-slate-900">
                      <Tag className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{item.costFact}</span>
                    </div>
                  </div>

                  {/* Expandable details drawer */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-slate-100 space-y-2 animate-in fade-in duration-200">
                      <p className="text-xs font-semibold text-slate-700">Key Clinical Features:</p>
                      <ul className="space-y-1.5">
                        {item.features.map((feat, idx) => (
                          <li key={idx} className="text-xs text-slate-600 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-sky-500 shrink-0"></span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Card Footer Actions */}
                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setExpandedId(isExpanded ? null : item.id)}
                    className="text-xs font-bold text-slate-600 hover:text-sky-600 flex items-center gap-1 transition cursor-pointer"
                    aria-expanded={isExpanded}
                  >
                    <span>{isExpanded ? 'Less info' : 'Learn more'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectTreatment(item.name)}
                    className="bg-orange-50 hover:bg-orange-100 text-orange-600 text-xs font-bold px-3.5 py-1.5 rounded-full transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>Book this</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
