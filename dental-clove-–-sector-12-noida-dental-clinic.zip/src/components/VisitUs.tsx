import React from 'react';
import {
  MapPin,
  Clock,
  Phone,
  Mail,
  Car,
  Navigation,
  ExternalLink,
} from 'lucide-react';

export const VisitUs: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-slate-50 border-t border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold">
            <MapPin className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinic Location</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Visit Us in <span className="text-sky-600">Sector 12, Noida</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Easily accessible ground-floor dental practice with reserved patient parking and metro connectivity.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-6xl mx-auto">
          {/* Clinic Details Card */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-7 sm:p-8 border border-sky-100 shadow-sm flex flex-col justify-between space-y-6">
            <div className="space-y-6">
              {/* Address */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Clinic Address
                  </h3>
                  <p className="text-base font-bold text-slate-900 mt-0.5">
                    Dental Clove
                  </p>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    [FULL ADDRESS], Sector 12, Noida, Uttar Pradesh [PIN]
                  </p>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Opening Hours [HOURS]
                  </h3>
                  <div className="text-sm text-slate-800 mt-1 space-y-1 font-medium">
                    <div className="flex justify-between gap-4">
                      <span>Monday – Saturday:</span>
                      <span className="font-bold text-slate-900">10:00 AM – 08:00 PM</span>
                    </div>
                    <div className="flex justify-between gap-4">
                      <span>Sunday:</span>
                      <span className="font-bold text-sky-600">10:00 AM – 02:00 PM (By Appt)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Phone & Email */}
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Direct Contact
                  </h3>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">
                    Phone: <a href="tel:[PHONE +91]" className="hover:text-sky-600">[PHONE +91]</a>
                  </p>
                  <p className="text-sm text-slate-600">
                    Email: <a href="mailto:[EMAIL]" className="hover:text-sky-600">[EMAIL]</a>
                  </p>
                </div>
              </div>

              {/* Landmarks and Parking Notes */}
              <div className="flex items-start gap-4 pt-2 border-t border-slate-100">
                <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Landmarks & Parking
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mt-1">
                    Ground-floor clinic with ramp access. Dedicated visitor car parking available right outside. Close to Noida City Centre & Sector 16 Metro connectivity.
                  </p>
                </div>
              </div>
            </div>

            {/* Google Directions Button */}
            <div className="pt-4 border-t border-slate-100">
              <a
                href="https://maps.google.com/?q=Sector+12+Noida+Dental"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-slate-900 hover:bg-sky-600 text-white font-semibold text-sm py-3 rounded-2xl transition flex items-center justify-center gap-2 shadow-xs"
              >
                <Navigation className="w-4 h-4" />
                <span>Get Driving Directions</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60" />
              </a>
            </div>
          </div>

          {/* Embedded Google Map Frame */}
          <div className="lg:col-span-7 bg-white rounded-3xl overflow-hidden border border-sky-100 shadow-sm min-h-[380px] relative flex flex-col">
            <iframe
              title="Dental Clove Sector 12 Noida Location Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14013.251410659695!2d77.33649646401368!3d28.59039328243644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce51390f7d54b%3A0xe54e2f9864ff2823!2sSector%2012%2C%20Noida%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1710000000000!5m2!1sen!2sin"
              className="w-full h-full min-h-[360px] border-0"
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>

            <div className="p-3 bg-white border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="font-semibold text-slate-700">Dental Clove – Sector 12, Noida</span>
              <span>Serving local residents since 2016</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
