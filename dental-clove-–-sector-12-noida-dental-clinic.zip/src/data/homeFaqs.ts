export interface HomeFaqItem {
  question: string;
  answer: string;
}

export const HOME_FAQS: HomeFaqItem[] = [
  {
    question: 'Does a root canal hurt?',
    answer:
      'Root canal treatment at Dental Clove is virtually painless because our endodontist administers targeted local anaesthesia before any cleaning begins. Most patients across Sector 12 and Sector 18 describe feeling mild vibration rather than pain. Treatments take 1 to 2 sittings of 45 to 60 minutes, with transparent pricing starting from ₹[CLINIC PRICE] per tooth.',
  },
  {
    question: 'How long do braces or clear aligners take?',
    answer:
      'Clear aligners typically take 6 to 18 months, while traditional fixed braces take 12 to 24 months depending on crowding and bite alignment. Patients from Sector 12, Sector 62, and Noida Extension receive a 3D digital simulation showing exact expected movement before starting, with packages starting from ₹[CLINIC PRICE].',
  },
  {
    question: 'Are dental implants safe, and how long do they last?',
    answer:
      'Dental implants are biocompatible titanium posts that fuse permanently with the jawbone, designed to last 20 to 25+ years or a lifetime with routine oral hygiene. The 2-stage procedure takes 3 to 6 months for complete osseointegration, with single-tooth restorations starting from ₹[CLINIC PRICE] in Sector 12, Noida.',
  },
  {
    question: 'Is teeth whitening safe?',
    answer:
      'Professional in-clinic teeth whitening is safe for tooth enamel when performed under dentist supervision using pH-balanced, desensitising LED bleaching gels. In a single 45-minute visit at our Sector 12 clinic, teeth brighten by 3 to 6 shades safely, with sessions starting from ₹[CLINIC PRICE].',
  },
  {
    question: 'At what age should my child first visit the dentist?',
    answer:
      'Children should have their first dental visit by age 1 or within 6 months of their first baby tooth erupting. These gentle, zero-fear "lap exams" in Sector 12 help prevent early childhood cavities and establish positive habits for families visiting from Greater Noida, Indirapuram, and Delhi NCR.',
  },
  {
    question: 'Do you offer 0% EMI or payment plans in Noida?',
    answer:
      'Yes, Dental Clove provides 0% interest EMI options spanning 3 to 18 months for clear aligners, orthodontic braces, and dental implants. Patients from Sector 12, Sector 18, and across Delhi NCR can start treatment with minimal down payment and transparent, itemised billing.',
  },
  {
    question: 'How do I book an appointment at Dental Clove in Sector 12?',
    answer:
      'You can book an appointment in under 60 seconds using the online booking form on this website, messaging our clinic directly on WhatsApp, or calling [PHONE +91]. Our Sector 12, Noida clinic operates Monday to Saturday from 10:00 AM to 08:00 PM and Sundays by appointment.',
  },
];
