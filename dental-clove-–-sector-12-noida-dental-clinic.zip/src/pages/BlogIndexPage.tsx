import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, User, Clock, ArrowRight, BookOpen, ShieldCheck } from 'lucide-react';
import { BLOG_ARTICLES, CLINIC_NAP } from '../data/blogData.ts';
import { SEOHead } from '../components/SEOHead.tsx';
import { NapBlock } from '../components/NapBlock.tsx';
import { handleImageError } from '../utils/imageFallback.ts';

interface BlogIndexPageProps {
  onOpenBooking: () => void;
}

export const BlogIndexPage: React.FC<BlogIndexPageProps> = ({ onOpenBooking }) => {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    name: 'Dental Health Blog Noida – Dental Clove Clinic',
    description:
      'Evidence-based dental guides from Sector 12, Noida dentists. Learn about root canals, braces, aligners & dental implant costs in Noida.',
    url: 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app/blog',
    publisher: {
      '@type': 'Dentist',
      name: CLINIC_NAP.name,
      telephone: CLINIC_NAP.phone,
      address: {
        '@type': 'PostalAddress',
        streetAddress: CLINIC_NAP.streetAddress,
        addressLocality: CLINIC_NAP.locality,
        addressRegion: CLINIC_NAP.region,
        postalCode: CLINIC_NAP.postalCode,
        addressCountry: CLINIC_NAP.country,
      },
    },
    breadcrumb: {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        {
          '@type': 'ListItem',
          position: 1,
          name: 'Home',
          item: 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app/',
        },
        {
          '@type': 'ListItem',
          position: 2,
          name: 'Dental Blog',
          item: 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app/blog',
        },
      ],
    },
  };

  return (
    <div className="bg-slate-50 min-h-screen pt-8 pb-20">
      <SEOHead
        title="Dental Health Blog Noida | Dental Clove Clinic"
        description="Evidence-based dental guides from Sector 12, Noida dentists. Learn about root canals, braces, aligners & dental implant costs in Noida."
        canonicalPath="/blog"
        ogType="website"
        jsonLd={jsonLd}
      />

      {/* Main Container */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumbs" className="mb-6 text-xs text-slate-500 flex items-center gap-2">
          <Link to="/" className="hover:text-sky-600 transition">
            Home
          </Link>
          <span>/</span>
          <span className="text-slate-800 font-semibold" aria-current="page">
            Blog
          </span>
        </nav>

        {/* Page Header (Single H1) */}
        <div className="mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 text-sky-800 text-xs font-bold border border-sky-200">
            <BookOpen className="w-3.5 h-3.5 text-sky-600" />
            <span>Sector 12, Noida Dental Education</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Dental Health &amp; Treatment Guides for Noida Residents
          </h1>
          <p className="text-base sm:text-lg text-slate-600 max-w-3xl leading-relaxed">
            Dental Clove publishes evidence-based, transparent clinical guides to help families across Sector 12,
            Sector 18, Sector 62, Noida Extension, Greater Noida, and Indirapuram understand treatment steps, realistic
            durations, and fair costs without medical jargon or exaggerated claims.
          </p>
        </div>

        {/* Featured Articles Grid */}
        <div className="space-y-8 mb-16">
          <h2 className="text-2xl font-bold text-slate-900 border-b border-slate-200 pb-3">
            Latest Clinical Articles &amp; Patient Guides
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {BLOG_ARTICLES.map((article) => (
              <article
                key={article.slug}
                className="bg-white rounded-3xl overflow-hidden border border-slate-200/90 shadow-sm hover:shadow-md hover:border-sky-300 transition flex flex-col justify-between group"
              >
                <div>
                  {/* Article Hero Thumbnail with Descriptive Alt Text */}
                  <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                    <img
                      src={article.heroImage}
                      alt={article.heroImageAlt}
                      className="w-full h-full object-cover group-hover:scale-103 transition duration-500"
                      loading="lazy"
                      onError={(e) => handleImageError(e)}
                    />
                    <div className="absolute top-3 right-3 bg-white/95 px-2.5 py-1 rounded-full text-[11px] font-bold text-slate-700 shadow-xs flex items-center gap-1">
                      <Clock className="w-3 h-3 text-sky-600" />
                      <span>{article.readTime}</span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-6 space-y-3">
                    <div className="text-xs text-slate-400 flex items-center gap-3">
                      <span className="flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-sky-600" />
                        {article.author}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {article.lastReviewedDate}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-sky-600 transition leading-snug">
                      <Link to={`/blog/${article.slug}`}>{article.title}</Link>
                    </h3>

                    {/* Direct Citable Summary Teaser */}
                    <p className="text-xs sm:text-sm text-slate-600 line-clamp-3 leading-relaxed">
                      {article.keyAnswerSummary}
                    </p>
                  </div>
                </div>

                <div className="p-6 pt-0 border-t border-slate-100 mt-2">
                  <Link
                    to={`/blog/${article.slug}`}
                    className="inline-flex items-center gap-2 text-sm font-bold text-sky-600 group-hover:text-sky-700 hover:gap-3 transition-all pt-3"
                  >
                    <span>Read Full Guide</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* CTA Banner */}
        <div className="bg-gradient-to-r from-sky-900 to-slate-900 rounded-3xl p-8 sm:p-10 text-white text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-6 mb-12 shadow-xl">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-sky-300">
              <ShieldCheck className="w-4 h-4" />
              <span>Honest Consultations in Sector 12, Noida</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Have Questions About Your Dental Health?
            </h2>
            <p className="text-sm text-slate-300">
              Speak directly with our experienced dentists. We discuss timelines, realistic expectations, and itemised costs
              before any treatment starts.
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenBooking}
            className="shrink-0 bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm px-7 py-3.5 rounded-full shadow-lg shadow-orange-500/30 flex items-center gap-2 transition cursor-pointer"
          >
            <span>Book Appointment</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Consistent NAP Block */}
        <NapBlock />
      </div>
    </div>
  );
};
