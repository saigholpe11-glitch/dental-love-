import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import {
  Calendar,
  User,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  MessageCircle,
  Stethoscope,
} from 'lucide-react';
import { BLOG_ARTICLES, CLINIC_NAP } from '../data/blogData.ts';
import { SEOHead } from '../components/SEOHead.tsx';
import { NapBlock } from '../components/NapBlock.tsx';
import { createWhatsAppBookingLink } from '../utils/booking.ts';
import { handleImageError } from '../utils/imageFallback.ts';

interface BlogPostPageProps {
  onOpenBooking: (treatmentName?: string) => void;
}

export const BlogPostPage: React.FC<BlogPostPageProps> = ({ onOpenBooking }) => {
  const { slug } = useParams<{ slug: string }>();
  const article = BLOG_ARTICLES.find((a) => a.slug === slug);

  if (!article) {
    return <Navigate to="/blog" replace />;
  }

  const whatsappUrl = createWhatsAppBookingLink({
    fullName: '',
    treatment: article.relatedTreatmentName,
  });

  const BASE_URL = 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app';
  const articleUrl = `${BASE_URL}/blog/${article.slug}`;

  // Combined Rich JSON-LD Schemas (BlogPosting, FAQPage, BreadcrumbList, Dentist)
  const jsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'BlogPosting',
      headline: article.title,
      name: article.seoTitle,
      description: article.metaDescription,
      image: [article.heroImage],
      datePublished: article.publishedDate,
      dateModified: '2026-10-20',
      author: {
        '@type': 'Person',
        name: article.author,
        jobTitle: article.authorRole,
        worksFor: {
          '@type': 'Dentist',
          name: CLINIC_NAP.name,
        },
      },
      publisher: {
        '@type': 'Dentist',
        name: CLINIC_NAP.name,
        telephone: CLINIC_NAP.phone,
        address: {
          '@type': 'PostalAddress',
          streetAddress: CLINIC_NAP.streetAddress,
          addressLocality: CLINIC_NAP.locality,
          addressRegion: CLINIC_NAP.region,
          postalCode: CLINIC_NAP.postalCode,
          addressCountry: CLINIC_NAP.country,
        },
      },
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': articleUrl,
      },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: article.faqs.map((faq) => ({
        '@type': 'Question',
        name: faq.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: faq.answer,
        },
      })),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        {
          '@type': 'ListItem',
          position: 1,
          name: 'Home',
          item: `${BASE_URL}/`,
        },
        {
          '@type': 'ListItem',
          position: 2,
          name: 'Blog',
          item: `${BASE_URL}/blog`,
        },
        {
          '@type': 'ListItem',
          position: 3,
          name: article.title,
          item: articleUrl,
        },
      ],
    },
  ];

  return (
    <article className="bg-slate-50 min-h-screen pt-8 pb-20">
      <SEOHead
        title={article.seoTitle}
        description={article.metaDescription}
        canonicalPath={article.canonicalPath}
        ogType="article"
        ogImage={article.heroImage}
        publishedTime={article.publishedDate}
        modifiedTime="2026-10-20"
        author={article.author}
        jsonLd={jsonLd}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumbs" className="mb-6 text-xs text-slate-500 flex items-center gap-2">
          <Link to="/" className="hover:text-sky-600 transition">
            Home
          </Link>
          <span>/</span>
          <Link to="/blog" className="hover:text-sky-600 transition">
            Blog
          </Link>
          <span>/</span>
          <span className="text-slate-800 font-semibold truncate max-w-xs sm:max-w-md" aria-current="page">
            {article.title}
          </span>
        </nav>

        {/* Article Header (Single H1) */}
        <header className="mb-8 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 text-sky-800 text-xs font-bold border border-sky-200">
            <Stethoscope className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinical Dental Guide • Sector 12, Noida</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            {article.title}
          </h1>

          {/* Author Byline & Review Meta */}
          <div className="pt-2 flex flex-wrap items-center gap-4 sm:gap-6 text-xs sm:text-sm text-slate-600 border-b border-slate-200 pb-5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                <User className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-900 block">{article.author}</span>
                <span className="text-xs text-slate-500">{article.authorRole}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-slate-500">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>Last reviewed: <strong className="text-slate-800 font-semibold">{article.lastReviewedDate}</strong></span>
            </div>

            <div className="flex items-center gap-1.5 text-slate-500">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>{article.readTime}</span>
            </div>
          </div>
        </header>

        {/* AI-Citable Key-Answer Summary Box at Top */}
        <div className="mb-10 bg-sky-50/90 border-2 border-sky-200 rounded-3xl p-6 sm:p-7 shadow-xs">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-sky-900 mb-2">
            <Sparkles className="w-4 h-4 text-sky-600" />
            <span>Quick Answer / Summary for Patients</span>
          </div>
          <p className="text-sm sm:text-base text-slate-800 font-medium leading-relaxed">
            {article.keyAnswerSummary}
          </p>
          <div className="mt-3 pt-3 border-t border-sky-200/70 text-[11px] text-sky-800 flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-700 shrink-0" />
            <span>Clinically verified by Dental Clove resident specialists • Sector 12, Noida Practice since 2016</span>
          </div>
        </div>

        {/* Hero Image with Descriptive Alt Text */}
        <div className="mb-10 rounded-3xl overflow-hidden shadow-md aspect-16/9 bg-slate-100 border border-slate-200/80">
          <img
            src={article.heroImage}
            alt={article.heroImageAlt}
            className="w-full h-full object-cover"
            loading="eager"
            onError={(e) => handleImageError(e)}
          />
        </div>

        {/* Article H2 Sections (No skipped levels, begins with direct answer) */}
        <div className="space-y-10 text-slate-700 leading-relaxed text-base sm:text-lg mb-14">
          {article.sections.map((sec, idx) => (
            <section key={idx} className="space-y-4">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-snug">
                {sec.h2}
              </h2>
              {sec.paragraphs.map((p, pIdx) => (
                <p key={pIdx} className="text-slate-600 leading-relaxed text-base">
                  {p}
                </p>
              ))}

              {sec.bulletPoints && (
                <ul className="space-y-2 pt-1 pl-1">
                  {sec.bulletPoints.map((b, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-2.5 text-sm sm:text-base text-slate-700">
                      <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>

        {/* Internal Link to Relevant Treatment */}
        <div className="bg-white rounded-2xl border border-sky-100 p-6 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 mb-14">
          <div>
            <div className="text-xs font-bold text-sky-600 uppercase tracking-wider mb-1">
              Related Treatment at Dental Clove
            </div>
            <div className="text-lg font-bold text-slate-900">
              Need personalized advice on {article.relatedTreatmentName}?
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Explore our full clinical approach, sterilisation protocol, and step-by-step care in Sector 12, Noida.
            </p>
          </div>
          <Link
            to={`/${article.relatedTreatmentHash}`}
            className="shrink-0 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-sm px-5 py-2.5 rounded-full border border-sky-200 flex items-center gap-2 transition"
          >
            <span>View Treatment Details</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* FAQ Block (H2 header, H3 questions, standalone 1-2 sentence answers) */}
        <section className="mb-14 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-bold text-sky-600 uppercase tracking-wider mb-2">
            <HelpCircle className="w-4 h-4" />
            <span>Common Patient Inquiries</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-6">
            Frequently Asked Questions
          </h2>

          <div className="space-y-6 divide-y divide-slate-100">
            {article.faqs.map((faq, fIdx) => (
              <div key={fIdx} className={fIdx > 0 ? 'pt-6' : ''}>
                <h3 className="text-lg font-bold text-slate-900 mb-2">
                  {faq.question}
                </h3>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Book Appointment CTA Card */}
        <div className="bg-slate-900 rounded-3xl p-8 sm:p-10 text-white text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-6 mb-14 shadow-xl">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-400 block">
              Direct Clinical Consultation
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Schedule Your Visit in Sector 12, Noida
            </h2>
            <p className="text-sm text-slate-300">
              Meet our resident doctors for an unhurried evaluation, digital X-rays, and upfront cost clarity starting at
              ₹[CLINIC PRICE].
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => onOpenBooking(article.relatedTreatmentName)}
              className="w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm px-7 py-3.5 rounded-full shadow-lg shadow-orange-500/30 flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <span>Book Appointment</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-6 py-3.5 rounded-full shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Consistent NAP Block */}
        <NapBlock />
      </div>
    </article>
  );
};
