import React from 'react';
import { Hero } from '../components/Hero.tsx';
import { Marquee } from '../components/Marquee.tsx';
import { Treatments } from '../components/Treatments.tsx';
import { About } from '../components/About.tsx';
import { Doctors } from '../components/Doctors.tsx';
import { BracesVsAligners } from '../components/BracesVsAligners.tsx';
import { KidsCorner } from '../components/KidsCorner.tsx';
import { FirstVisitSteps } from '../components/FirstVisitSteps.tsx';
import { SmileGallery } from '../components/SmileGallery.tsx';
import { PatientReviews } from '../components/PatientReviews.tsx';
import { FaqSection } from '../components/FaqSection.tsx';
import { BookingSection } from '../components/BookingSection.tsx';
import { VisitUs } from '../components/VisitUs.tsx';
import { SEOHead } from '../components/SEOHead.tsx';
import { NapBlock } from '../components/NapBlock.tsx';
import { CLINIC_NAP } from '../data/blogData.ts';
import { HOME_FAQS } from '../data/homeFaqs.ts';

interface HomePageProps {
  onOpenBooking: (treatmentName?: string) => void;
  selectedTreatment: string;
}

export const HomePage: React.FC<HomePageProps> = ({ onOpenBooking, selectedTreatment }) => {
  const BASE_URL = 'https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app';

  // Comprehensive Schema.org JSON-LD (Dentist / LocalBusiness + FAQPage)
  const homeJsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'Dentist',
      name: CLINIC_NAP.name,
      alternateName: 'Dental Clove Sector 12 Noida',
      image: `${BASE_URL}/images/operatory.jpg`,
      telephone: CLINIC_NAP.phone,
      email: CLINIC_NAP.email,
      url: `${BASE_URL}/`,
      foundingDate: CLINIC_NAP.foundingDate,
      priceRange: '₹₹',
      currenciesAccepted: 'INR',
      paymentAccepted: 'Cash, UPI, Credit Card, Debit Card, EMI',
      address: {
        '@type': 'PostalAddress',
        streetAddress: CLINIC_NAP.streetAddress,
        addressLocality: CLINIC_NAP.locality,
        addressRegion: CLINIC_NAP.region,
        postalCode: CLINIC_NAP.postalCode,
        addressCountry: CLINIC_NAP.country,
      },
      geo: {
        '@type': 'GeoCoordinates',
        latitude: CLINIC_NAP.coordinates.latitude,
        longitude: CLINIC_NAP.coordinates.longitude,
      },
      openingHoursSpecification: [
        {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
          opens: '10:00',
          closes: '20:00',
        },
        {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: ['Sunday'],
          opens: '10:00',
          closes: '14:00',
        },
      ],
      sameAs: [
        'https://facebook.com/dentalclove',
        'https://instagram.com/dentalclove',
        'https://maps.google.com/?q=Sector+12+Noida+Dental',
      ],
      areaServed: [
        'Sector 12, Noida',
        'Sector 18, Noida',
        'Sector 62, Noida',
        'Noida Extension',
        'Greater Noida',
        'Indirapuram',
        'Delhi NCR',
      ],
      description:
        'Gentle, honest dental care in Sector 12, Noida since 2016. Specialising in general dentistry, rotary root canals, braces, clear aligners, dental implants, teeth whitening, and paediatric dentistry with transparent pricing from ₹[CLINIC PRICE].',
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: HOME_FAQS.map((faq) => ({
        '@type': 'Question',
        name: faq.question,
        acceptedAnswer: {
          '@type': 'Answer',
          text: faq.answer,
        },
      })),
    },
  ];

  return (
    <>
      {/* Homepage SEO Head */}
      <SEOHead
        title="Dentist in Sector 12, Noida | Dental Clove Clinic"
        description="Looking for a trusted dentist in Sector 12, Noida? Dental Clove provides gentle root canals, braces, aligners & implants. Book your visit."
        canonicalPath="/"
        ogType="website"
        jsonLd={homeJsonLd}
      />

      {/* 2. Hero Section */}
      <Hero onOpenBooking={onOpenBooking} />

      {/* 3. Marquee Band */}
      <Marquee />

      {/* 4. Treatments (7 outline-icon cards) */}
      <Treatments onSelectTreatment={onOpenBooking} />

      {/* 5. About the Clinic */}
      <About />

      {/* 6. Meet the Doctors (exactly 2 resident doctors) */}
      <Doctors onOpenBooking={() => onOpenBooking()} />

      {/* 7. Braces vs Aligners (with Three.js 3D Explorer) */}
      <BracesVsAligners onOpenBooking={() => onOpenBooking('Clear Aligners')} />

      {/* 8. Kids' Corner */}
      <KidsCorner onOpenBooking={() => onOpenBooking('Paediatric Dentistry')} />

      {/* 9. What to Expect on Your First Visit */}
      <FirstVisitSteps onOpenBooking={() => onOpenBooking()} />

      {/* 10. Smile Gallery (Before/After Slider) */}
      <SmileGallery />

      {/* 11. Patient Reviews */}
      <PatientReviews />

      {/* 12. FAQ Accordion */}
      <FaqSection />

      {/* 13. Book Appointment (Navy Banner & Form) */}
      <BookingSection initialTreatment={selectedTreatment} />

      {/* 14. Visit Us */}
      <VisitUs />

      {/* 15. Standard NAP Block in container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-slate-50">
        <NapBlock />
      </div>
    </>
  );
};
