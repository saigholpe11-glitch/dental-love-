import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isValidIndianPhone,
  validateBookingForm,
  createWhatsAppBookingLink,
  ALLOWED_TREATMENTS,
  BRACES_VS_ALIGNERS_DATA,
} from './booking.ts';

test('phone validation detects valid Indian phone numbers', () => {
  assert.equal(isValidIndianPhone('9876543210'), true);
  assert.equal(isValidIndianPhone('+919876543210'), true);
  assert.equal(isValidIndianPhone('09876543210'), true);
  assert.equal(isValidIndianPhone('98765-43210'), true);
  assert.equal(isValidIndianPhone('7890123456'), true);
});

test('phone validation rejects invalid phone numbers', () => {
  assert.equal(isValidIndianPhone('1234567890'), false); // Starts with 1
  assert.equal(isValidIndianPhone('98765'), false); // Too short
  assert.equal(isValidIndianPhone('abcdefghij'), false);
  assert.equal(isValidIndianPhone(''), false);
});

test('booking form validation validates required fields and future date', () => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const validData = {
    fullName: 'Rahul Sharma',
    phone: '9876543210',
    treatment: 'Clear Aligners',
    preferredDate: tomorrowStr,
    preferredTime: '11:00 AM - 01:00 PM',
  };

  const result = validateBookingForm(validData);
  assert.equal(result.isValid, true);
  assert.equal(Object.keys(result.errors).length, 0);
});

test('booking form rejects empty fields and unknown treatments', () => {
  const invalidData = {
    fullName: '',
    phone: '123',
    treatment: 'Cardiology', // Not offered at Dental Clove
    preferredDate: '',
    preferredTime: '',
  };

  const result = validateBookingForm(invalidData);
  assert.equal(result.isValid, false);
  assert.ok(result.errors.fullName);
  assert.ok(result.errors.phone);
  assert.ok(result.errors.treatment);
  assert.ok(result.errors.preferredDate);
  assert.ok(result.errors.preferredTime);
});

test('whatsapp booking link generation includes patient details and clinic number', () => {
  const link = createWhatsAppBookingLink({
    fullName: 'Priya Verma',
    treatment: 'Root Canal Treatment',
    preferredDate: '2026-10-20',
    preferredTime: '05:00 PM - 07:00 PM',
  });

  assert.ok(link.startsWith('https://wa.me/919876543210?text='));
  assert.ok(link.includes('Priya%20Verma'));
  assert.ok(link.includes('Root%20Canal%20Treatment'));
});

test('allowed treatments list strictly contains only the 7 allowed specialties', () => {
  assert.equal(ALLOWED_TREATMENTS.length, 7);
  assert.deepEqual([...ALLOWED_TREATMENTS], [
    'General Dentistry',
    'Root Canal Treatment',
    'Braces',
    'Clear Aligners',
    'Dental Implants',
    'Teeth Whitening',
    'Paediatric Dentistry',
  ]);
});

test('braces vs aligners matrix has all required comparison points', () => {
  assert.ok(BRACES_VS_ALIGNERS_DATA.length >= 5);
  const visibilityItem = BRACES_VS_ALIGNERS_DATA.find((item) =>
    item.feature.includes('Visibility')
  );
  assert.ok(visibilityItem);
  assert.ok(visibilityItem.aligners.includes('invisible'));
});
