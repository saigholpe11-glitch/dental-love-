/**
 * Business logic and data helpers for Dental Clove clinic
 */

export const ALLOWED_TREATMENTS = [
  'General Dentistry',
  'Root Canal Treatment',
  'Braces',
  'Clear Aligners',
  'Dental Implants',
  'Teeth Whitening',
  'Paediatric Dentistry',
] as const;

export type TreatmentType = (typeof ALLOWED_TREATMENTS)[number];

export interface BookingFormData {
  fullName: string;
  phone: string;
  treatment: string;
  preferredDate: string;
  preferredTime: string;
  notes?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

/**
 * Validates Indian 10-digit phone numbers with optional +91 or 0 prefix
 */
export function isValidIndianPhone(phone: string): boolean {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  // Matches 10 digits starting with 6-9, or +91 / 91 followed by 10 digits starting with 6-9
  const regex = /^(?:(?:\+?91)|0)?[6789]\d{9}$/;
  return regex.test(cleaned);
}

/**
 * Validates dental appointment booking submission
 */
export function validateBookingForm(data: Partial<BookingFormData>): ValidationResult {
  const errors: Record<string, string> = {};

  const name = (data.fullName || '').trim();
  if (!name) {
    errors.fullName = 'Please enter your full name';
  } else if (name.length < 2) {
    errors.fullName = 'Name must be at least 2 characters';
  }

  const phone = (data.phone || '').trim();
  if (!phone) {
    errors.phone = 'Please enter your phone number';
  } else if (!isValidIndianPhone(phone)) {
    errors.phone = 'Please enter a valid 10-digit mobile number';
  }

  const treatment = (data.treatment || '').trim();
  if (!treatment) {
    errors.treatment = 'Please select a treatment';
  } else if (!ALLOWED_TREATMENTS.includes(treatment as TreatmentType)) {
    errors.treatment = 'Please select a valid treatment from the list';
  }

  const date = (data.preferredDate || '').trim();
  if (!date) {
    errors.preferredDate = 'Please select a preferred date';
  } else {
    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (isNaN(selectedDate.getTime())) {
      errors.preferredDate = 'Invalid date selected';
    } else if (selectedDate < today) {
      errors.preferredDate = 'Date cannot be in the past';
    }
  }

  const time = (data.preferredTime || '').trim();
  if (!time) {
    errors.preferredTime = 'Please choose a preferred time slot';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Formats a WhatsApp booking enquiry message and link
 */
export function createWhatsAppBookingLink(
  data: Partial<BookingFormData>,
  clinicWhatsAppNumber: string = '919876543210'
): string {
  const name = data.fullName?.trim() || 'Patient';
  const treatment = data.treatment || 'Consultation';
  const date = data.preferredDate || 'Earliest available';
  const time = data.preferredTime || 'Any convenient slot';
  const notes = data.notes?.trim() ? `\nNote: ${data.notes.trim()}` : '';

  const message = `Hello Dental Clove! I would like to book a dental consultation in Sector 12, Noida.\n\n👤 Name: ${name}\n🦷 Treatment: ${treatment}\n📅 Preferred Date: ${date}\n⏰ Preferred Slot: ${time}${notes}\n\nPlease confirm availability. Thank you!`;

  return `https://wa.me/${clinicWhatsAppNumber}?text=${encodeURIComponent(message)}`;
}

export interface BracesComparisonItem {
  feature: string;
  braces: string;
  aligners: string;
  tag?: string;
}

export const BRACES_VS_ALIGNERS_DATA: BracesComparisonItem[] = [
  {
    feature: 'Visibility & Aesthetics',
    braces: 'Visible metal or ceramic brackets and wires',
    aligners: 'Virtually invisible, custom-moulded clear medical-grade polymer',
    tag: 'Aesthetic winner',
  },
  {
    feature: 'Comfort & Mouth Feel',
    braces: 'Occasional cheek irritation; wires may need periodic wax relief',
    aligners: 'Smooth, laser-cut edges; zero sharp brackets or wire pokes',
    tag: 'Daily comfort',
  },
  {
    feature: 'Diet & Food Freedom',
    braces: 'Avoid sticky, hard, or chewy food (e.g., hard chikki, whole apples)',
    aligners: 'Completely removable — eat all your favourite foods freely',
    tag: 'Lifestyle freedom',
  },
  {
    feature: 'Oral Hygiene & Brushing',
    braces: 'Requires special orthodontic brushes and flossing threaders',
    aligners: 'Pop out trays to brush and floss your teeth normally',
  },
  {
    feature: 'Average Treatment Duration',
    braces: '12 – 24 months depending on bite complexity',
    aligners: '6 – 18 months for mild to moderate corrections',
  },
  {
    feature: 'Who it suits best',
    braces: 'Complex malocclusions, severe rotations, teens & adults',
    aligners: 'Mild-to-moderate alignment, working professionals, college students & conscious smiles',
  },
];
