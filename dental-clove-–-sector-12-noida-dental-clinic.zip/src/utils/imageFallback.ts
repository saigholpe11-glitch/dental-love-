import React from 'react';

// Generates an inline SVG data URI as ultimate foolproof fallback
export const DENTAL_FALLBACK_SVG =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" viewBox="0 0 800 600" fill="#f0f9ff">
  <rect width="800" height="600" fill="#f0f9ff"/>
  <circle cx="400" cy="300" r="160" fill="#e0f2fe"/>
  <path d="M400 190 C360 190 330 220 330 260 C330 295 345 360 355 400 C365 440 375 450 390 450 C405 450 415 440 425 400 C435 360 450 295 450 260 C450 220 420 190 380 190 Z" fill="#0284c7" opacity="0.8"/>
  <text x="400" y="490" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="22" fill="#0369a1">Dental Clove • Sector 12, Noida</text>
</svg>
`);

export const handleImageError = (
  e: React.SyntheticEvent<HTMLImageElement, Event>,
  localFallbackPath?: string
) => {
  const target = e.currentTarget;
  if (localFallbackPath && target.src !== localFallbackPath && !target.src.endsWith(localFallbackPath)) {
    target.src = localFallbackPath;
  } else if (target.src !== DENTAL_FALLBACK_SVG) {
    target.src = DENTAL_FALLBACK_SVG;
  }
};
