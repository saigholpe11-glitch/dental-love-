import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { BLOG_ARTICLES, CLINIC_NAP } from '../data/blogData.ts';
import { HOME_FAQS } from '../data/homeFaqs.ts';

test('Homepage SEO requirements: title under 60 chars and description under 155 chars with Noida', () => {
  const homeTitle = 'Dentist in Sector 12, Noida | Dental Clove Clinic';
  const homeDesc =
    'Looking for a trusted dentist in Sector 12, Noida? Dental Clove provides gentle root canals, braces, aligners & implants. Book your visit.';

  assert.ok(homeTitle.length <= 60, `Home title too long: ${homeTitle.length} chars`);
  assert.ok(homeTitle.includes('Noida'), 'Home title must contain Noida');

  assert.ok(homeDesc.length <= 155, `Home description too long: ${homeDesc.length} chars`);
  assert.ok(homeDesc.includes('Noida'), 'Home description must contain Noida');
});

test('Blog Index SEO requirements: title under 60 chars and description under 155 chars with Noida', () => {
  const blogTitle = 'Dental Health Blog Noida | Dental Clove Clinic';
  const blogDesc =
    'Evidence-based dental guides from Sector 12, Noida dentists. Learn about root canals, braces, aligners & dental implant costs in Noida.';

  assert.ok(blogTitle.length <= 60, `Blog title too long: ${blogTitle.length} chars`);
  assert.ok(blogTitle.includes('Noida'), 'Blog title must contain Noida');

  assert.ok(blogDesc.length <= 155, `Blog description too long: ${blogDesc.length} chars`);
  assert.ok(blogDesc.includes('Noida'), 'Blog description must contain Noida');
});

test('Blog articles: exactly 3 articles exist with required slugs', () => {
  assert.equal(BLOG_ARTICLES.length, 3, 'Must have exactly 3 blog articles');

  const slugs = BLOG_ARTICLES.map((a) => a.slug);
  assert.ok(slugs.includes('is-root-canal-painful-noida'), 'Missing root canal article');
  assert.ok(slugs.includes('braces-vs-clear-aligners-noida'), 'Missing braces vs aligners article');
  assert.ok(slugs.includes('dental-implants-noida-cost'), 'Missing dental implants article');
});

test('Blog articles: each article satisfies title and meta description constraints', () => {
  for (const article of BLOG_ARTICLES) {
    assert.ok(
      article.seoTitle.length <= 60,
      `Article "${article.title}" seoTitle too long: ${article.seoTitle.length} chars (must be <= 60)`
    );
    assert.ok(
      article.seoTitle.toLowerCase().includes('noida'),
      `Article "${article.title}" seoTitle must contain "Noida"`
    );

    assert.ok(
      article.metaDescription.length <= 155,
      `Article "${article.title}" metaDescription too long: ${article.metaDescription.length} chars (must be <= 155)`
    );
    assert.ok(
      article.metaDescription.toLowerCase().includes('noida'),
      `Article "${article.title}" metaDescription must contain "Noida"`
    );
  }
});

test('Blog articles: each article has byline [DOCTOR NAME], reviewed date, summary box, 4-6 H2s and FAQs', () => {
  for (const article of BLOG_ARTICLES) {
    assert.ok(article.author.includes('[DOCTOR NAME]'), 'Author byline must be [DOCTOR NAME]');
    assert.ok(article.lastReviewedDate.length > 0, 'Must have a last reviewed date');
    assert.ok(article.keyAnswerSummary.length >= 60, 'Must have a standalone key-answer summary');
    assert.ok(
      article.sections.length >= 4 && article.sections.length <= 6,
      `Article "${article.title}" must have 4-6 H2 sections, got ${article.sections.length}`
    );
    assert.ok(article.faqs.length >= 3, `Article "${article.title}" must have an FAQ block`);

    for (const faq of article.faqs) {
      assert.ok(faq.question.length > 5, 'FAQ question must be valid');
      assert.ok(faq.answer.length > 15, 'FAQ answer must be valid');
    }
  }
});

test('Local business NAP and founding date verified', () => {
  assert.equal(CLINIC_NAP.name, 'Dental Clove');
  assert.equal(CLINIC_NAP.foundingDate, '2016');
  assert.ok(CLINIC_NAP.locality.includes('Sector 12, Noida'));
  assert.ok(CLINIC_NAP.phone.includes('[PHONE'));
});

test('robots.txt allows all crawlers including GPTBot, PerplexityBot, Google-Extended and links sitemap', () => {
  const robotsPath = path.resolve('public/robots.txt');
  assert.ok(fs.existsSync(robotsPath), 'public/robots.txt must exist');
  const content = fs.readFileSync(robotsPath, 'utf8');

  assert.ok(content.includes('User-agent: *'), 'Must contain User-agent: *');
  assert.ok(content.includes('User-agent: GPTBot'), 'Must allow GPTBot');
  assert.ok(content.includes('User-agent: PerplexityBot'), 'Must allow PerplexityBot');
  assert.ok(content.includes('User-agent: Google-Extended'), 'Must allow Google-Extended');
  assert.ok(content.includes('Sitemap:'), 'Must link to sitemap');
});

test('sitemap.xml contains homepage, blog index and all 3 blog articles', () => {
  const sitemapPath = path.resolve('public/sitemap.xml');
  assert.ok(fs.existsSync(sitemapPath), 'public/sitemap.xml must exist');
  const content = fs.readFileSync(sitemapPath, 'utf8');

  assert.ok(content.includes('<loc>https://ais-pre-rv2qzzwcqwdhqnmwquqbsk-814909955316.asia-southeast1.run.app/</loc>'));
  assert.ok(content.includes('/blog</loc>'));
  assert.ok(content.includes('/blog/is-root-canal-painful-noida</loc>'));
  assert.ok(content.includes('/blog/braces-vs-clear-aligners-noida</loc>'));
  assert.ok(content.includes('/blog/dental-implants-noida-cost</loc>'));
});

test('Homepage FAQs start with direct standalone answers and mention costs with ₹', () => {
  assert.ok(HOME_FAQS.length >= 7, 'Must have at least 7 homepage FAQs');
  for (const faq of HOME_FAQS) {
    assert.ok(faq.question.length > 0);
    assert.ok(faq.answer.length > 30);
  }
  // Check ₹[CLINIC PRICE] appears in pricing FAQs
  const costFaq = HOME_FAQS.find((f) => f.question.toLowerCase().includes('root canal'));
  assert.ok(costFaq && costFaq.answer.includes('₹[CLINIC PRICE]'));
});
